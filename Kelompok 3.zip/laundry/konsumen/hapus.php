<?php
include '../config/koneksi.php';

$id = $_GET['id'];

$cek = mysqli_query($conn, "SELECT COUNT(*) AS total FROM transaksi WHERE id_konsumen = '$id'");
$data = mysqli_fetch_assoc($cek);

if ($data['total'] > 0) {
    header("Location: index.php?msg=terpakai");
    exit;
}
mysqli_query($conn, "DELETE FROM konsumen WHERE id = '$id'");
header("Location: index.php?msg=hapus_sukses");
exit;
