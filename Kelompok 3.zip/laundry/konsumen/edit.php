<?php
include '../config/koneksi.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM konsumen WHERE id = $id");
$data = mysqli_fetch_assoc($result);

if (isset($_POST['update'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telp = $_POST['telp'];

    mysqli_query($conn, "UPDATE konsumen SET nama='$nama', alamat='$alamat', telp='$telp' WHERE id=$id");
    $_SESSION['update_success'] = true;
    header("Location: edit.php?id=$id");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Konsumen</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes buttonPulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        body {
            background: linear-gradient(to right, #74ebd5, #acb6e5);
            font-family: 'Segoe UI', sans-serif;
            padding: 30px;
            animation: slideIn 0.6s ease-out;
        }

        .edit-container {
            max-width: 520px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 14px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            animation: slideIn 1s ease;
        }

        h2 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 25px;
        }

        label {
            font-weight: bold;
            color: #34495e;
        }

        input[type="text"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 18px;
            border-radius: 8px;
            border: 1px solid #ccc;
            transition: 0.3s;
        }

        input[type="text"]:focus {
            border-color: #3498db;
            box-shadow: 0 0 8px rgba(52, 152, 219, 0.2);
        }

        .button {
            padding: 10px 18px;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-block;
            animation: buttonPulse 2s infinite;
        }

        .button.save {
            background-color: #3498db;
            color: white;
        }

        .button.save:hover {
            background-color: #2980b9;
            transform: scale(1.05);
        }

        .button.back {
            background-color: #bdc3c7;
            color: black;
            margin-left: 10px;
        }

        .button.back:hover {
            background-color: #95a5a6;
            transform: scale(1.05);
        }
    </style>
</head>
<body>

    <div class="edit-container">
        <h2>✏️ Edit Data Konsumen</h2>
        <form method="post">
            <label>Nama:</label>
            <input type="text" name="nama" value="<?= $data['nama']; ?>" required>

            <label>Alamat:</label>
            <input type="text" name="alamat" value="<?= $data['alamat']; ?>" required>

            <label>Telp:</label>
            <input type="text" name="telp" value="<?= $data['telp']; ?>" required>

            <button type="submit" name="update" class="button save">💾 Simpan Perubahan</button>
            <a href="index.php" class="button back">⬅️ Kembali</a>
        </form>
    </div>

    <!-- Suara klik -->
    <audio id="click-sound" src="../assets/sound/click.mp3" preload="auto"></audio>
    <script>
        const clickSound = document.getElementById("click-sound");
        document.querySelectorAll("button, a.button").forEach(btn => {
            btn.addEventListener("click", () => {
                clickSound.play();
            });
        });
    </script>

    <!-- SweetAlert notifikasi update -->
    <?php if (isset($_SESSION['update_success'])): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Data konsumen berhasil diperbarui.',
                confirmButtonText: 'OK',
                timer: 2000,
                timerProgressBar: true
            });
        </script>
        <?php unset($_SESSION['update_success']); ?>
    <?php endif; ?>

</body>
</html>
