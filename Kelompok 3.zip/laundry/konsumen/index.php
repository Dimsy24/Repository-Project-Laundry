<?php
include '../config/koneksi.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

$result = mysqli_query($conn, "SELECT * FROM konsumen");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Konsumen</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        @keyframes fadeInCard {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes bounceButton {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }

        @keyframes pulseGlow {
            0% { box-shadow: 0 0 0 rgba(255, 255, 255, 0); }
            50% { box-shadow: 0 0 20px rgba(255, 255, 255, 0.4); }
            100% { box-shadow: 0 0 0 rgba(255, 255, 255, 0); }
        }

        body.konsumen-page {
            background-image: url("../assets/img/konsumen.jpg");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
            padding: 30px;
            color: white;
            position: relative;
            z-index: 1;
            animation: fadeInCard 1s ease-in-out;
            font-family: "Segoe UI", sans-serif;
        }

        body.konsumen-page::before {
            content: "";
            position: absolute;
            top: 0; left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: -1;
        }

        h2 {
            text-align: center;
            color: #ffffff;
            margin-bottom: 30px;
            animation: fadeInCard 1.2s ease-in-out;
        }

        .konsumen-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .konsumen-card {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            padding: 20px;
            backdrop-filter: blur(8px);
            color: white;
            transform: translateY(20px);
            opacity: 0;
            animation: fadeInCard 0.6s ease forwards;
        }

        .konsumen-card:nth-child(1) { animation-delay: 0.1s; }
        .konsumen-card:nth-child(2) { animation-delay: 0.2s; }
        .konsumen-card:nth-child(3) { animation-delay: 0.3s; }
        .konsumen-card:nth-child(4) { animation-delay: 0.4s; }

        .konsumen-card:hover {
            transform: translateY(-5px) scale(1.02);
        }

        .konsumen-card h3,
        .konsumen-card p {
            color: white;
            margin: 0 0 10px;
        }

        .card-buttons {
            margin-top: 10px;
            display: flex;
            gap: 10px;
        }

        .button {
            padding: 8px 14px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .button.edit {
            background: #27ae60;
            color: white;
            animation: bounceButton 1.2s infinite;
        }

        .button.delete {
            background: #e74c3c;
            color: white;
            animation: pulseGlow 2s infinite;
        }

        .button.edit:hover {
            background: #219150;
            transform: scale(1.05);
        }

        .button.delete:hover {
            background: #c0392b;
            transform: scale(1.05);
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .top-bar a {
            background-color: rgb(117, 128, 124);
            color: white;
            padding: 10px 16px;
            border-radius: 8px;
            font-weight: bold;
            animation: bounceButton 1.4s infinite;
        }

        .top-bar a:hover {
            background-color: #2980b9;
        }

        .back-btn {
            margin-top: 30px;
            text-align: center;
            animation: fadeInCard 1s ease;
        }

        .success-message, .error-message {
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 20px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
            animation: fadeInCard 0.8s ease;
        }

        .success-message {
            background-color: #eafaf1;
            color: #2ecc71;
            border-left: 5px solid #2ecc71;
        }

        .error-message {
            background-color: #fdecea;
            color: #e74c3c;
            border-left: 5px solid #e74c3c;
        }
    </style>
</head>
<body class="konsumen-page">
    <h2>📋 Data Konsumen</h2>

    <?php if (isset($_GET['msg'])): ?>
        <?php if ($_GET['msg'] == 'terpakai'): ?>
            <div class="error-message">❌ Gagal menghapus! Konsumen ini masih memiliki transaksi.</div>
        <?php elseif ($_GET['msg'] == 'hapus_sukses'): ?>
            <div class="success-message">✅ Data konsumen berhasil dihapus.</div>
        <?php endif; ?>
    <?php endif; ?>

    <div class="top-bar">
        <a href="tambah.php">➕ Tambah Konsumen</a>
    </div>

    <div class="konsumen-container">
        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
            <div class="konsumen-card">
                <h3><?= $row['nama']; ?></h3>
                <p>📍 <?= $row['alamat']; ?></p>
                <p>📞 <?= $row['telp']; ?></p>
                <div class="card-buttons">
                    <a href="edit.php?id=<?= $row['id'] ?>" class="button edit">✏️ Edit</a>
                    <a href="hapus.php?id=<?= $row['id'] ?>" class="button delete" onclick="return confirm('Yakin ingin hapus?')">🗑️ Hapus</a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <div class="back-btn">
        <a href="../dashboard.php" class="button" style="background:#3498db;">⬅️ Kembali ke Dashboard</a>
    </div>
</body>
</html>
