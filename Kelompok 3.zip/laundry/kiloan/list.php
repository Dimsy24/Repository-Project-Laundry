<?php
include '../config/koneksi.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

$query = mysqli_query($conn, "SELECT t.*, k.nama FROM transaksi t 
                              JOIN konsumen k ON t.id_konsumen = k.id 
                              ORDER BY t.id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Kiloan</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body.kiloan-page {
            background-image: url("../assets/img/kiloan.jpg");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
            margin: 0;
            padding: 40px;
            font-family: "Segoe UI", sans-serif;
        }

        h2 {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            text-shadow: 2px 2px 6px rgba(0,0,0,0.6);
            animation: fadeInDown 0.8s ease;
        }

        .table-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            overflow-x: auto;
            animation: popIn 0.9s ease;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 15px;
        }

        th, td {
            padding: 12px 16px;
            border-bottom: 1px solid #ddd;
            text-align: center;
            transition: all 0.3s ease;
        }

        th {
            background-color: #3498db;
            color: white;
            position: sticky;
            top: 0;
            z-index: 2;
        }

        tr:hover {
            background-color: #ecf6fd;
            transform: scale(1.01);
        }

        .button {
            background-color: #3498db;
            color: white;
            padding: 10px 18px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .button:hover {
            background-color: #2980b9;
            transform: scale(1.05);
        }

        .back-btn {
            margin-top: 30px;
            text-align: center;
            animation: fadeInUp 1s ease;
        }

        .success {
            background: #eafaf1;
            color: #2ecc71;
            padding: 14px;
            margin-bottom: 20px;
            border-left: 6px solid #2ecc71;
            border-radius: 6px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
            font-weight: bold;
            text-align: center;
            animation: fadeIn 0.8s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes popIn {
            0% { transform: scale(0.95); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }
    </style>
</head>
<body class="kiloan-page">

<h2>📋 Daftar Transaksi Kiloan</h2>

<?php if (isset($_GET['msg']) && $_GET['msg'] == 'selesai'): ?>
    <div class="success">✅ Transaksi berhasil diselesaikan!</div>
<?php endif; ?>

<div class="table-container">
    <table>
        <tr>
            <th>No</th>
            <th>Nama Konsumen</th>
            <th>Tanggal Masuk</th>
            <th>Tanggal Keluar</th>
            <th>Status</th>
            <th>Berat</th>
            <th>Total Harga</th>
        </tr>
        <?php $no = 1; while ($row = mysqli_fetch_assoc($query)) : ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $row['nama'] ?></td>
            <td><?= $row['tanggal_masuk'] ?></td>
            <td><?= $row['tanggal_keluar'] ? $row['tanggal_keluar'] : '-' ?></td>
            <td>
                <span style="color: <?= $row['status'] == 'Masuk' ? '#e67e22' : '#27ae60'; ?>; font-weight: bold;">
                    <?= $row['status'] ?>
                </span>
            </td>
            <td><?= $row['berat'] ?> kg</td>
            <td>Rp <?= number_format($row['total_harga']) ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<div class="back-btn">
    <a href="../dashboard.php" class="button">⬅️ Kembali ke Dashboard</a>
</div>

</body>
</html>
