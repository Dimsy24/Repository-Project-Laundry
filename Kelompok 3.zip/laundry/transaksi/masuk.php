<?php
include '../config/koneksi.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_konsumen = $_POST['id_konsumen'];
    $tanggal_masuk = $_POST['tanggal_masuk'];
    $berat = $_POST['berat'];
    $harga_per_kg = $_POST['harga_per_kg'];
    $total_harga = $berat * $harga_per_kg;

    mysqli_query($conn, "INSERT INTO transaksi (id_konsumen, tanggal_masuk, berat, harga_per_kg, total_harga, status) 
    VALUES ('$id_konsumen', '$tanggal_masuk', '$berat', '$harga_per_kg', '$total_harga', 'Masuk')");
    
    header("Location: keluar.php?msg=sukses");
    exit;
}

$konsumen = mysqli_query($conn, "SELECT * FROM konsumen");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Transaksi Masuk</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            background-image: url('../assets/img/masuk.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
            margin: 0;
            padding: 40px;
            font-family: 'Segoe UI', sans-serif;
        }

        h2 {
            text-align: center;
            color: white;
            text-shadow: 2px 2px 6px rgba(0,0,0,0.6);
            margin-bottom: 30px;
            animation: fadeDown 1s ease;
        }

        form {
            max-width: 550px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            animation: popIn 0.6s ease-in-out;
        }

        label {
            font-weight: bold;
            color: #34495e;
            display: block;
            margin-bottom: 5px;
        }

        input[type="date"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
        }

        .button {
            background-color: #8e44ad;
            color: white;
            padding: 10px 18px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s ease;
            display: inline-block;
            font-size: 15px;
        }

        .button:hover {
            background-color: #732d91;
            transform: scale(1.05);
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 25px;
        }

        @keyframes popIn {
            0% { transform: scale(0.9); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }

        @keyframes fadeDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

<h2>🧾 Input Transaksi Masuk</h2>

<form method="post">
    <label for="id_konsumen">👤 Nama Konsumen</label>
    <select name="id_konsumen" required>
        <option value="">-- Pilih Konsumen --</option>
        <?php while ($row = mysqli_fetch_assoc($konsumen)): ?>
            <option value="<?= $row['id'] ?>"><?= $row['nama'] ?></option>
        <?php endwhile; ?>
    </select>

    <label for="tanggal_masuk">📅 Tanggal Masuk</label>
    <input type="date" name="tanggal_masuk" required>

    <label for="berat">⚖️ Berat Cucian (Kg)</label>
    <input type="number" step="0.1" name="berat" required>

    <label for="harga_per_kg">💰 Harga per Kg</label>
    <input type="number" name="harga_per_kg" required>

    <button type="submit" class="button">✔️ Simpan Transaksi</button>
</form>

<div class="back">
    <a href="../dashboard.php" class="button">⬅️ Kembali ke Dashboard</a>
</div>

</body>
</html>
