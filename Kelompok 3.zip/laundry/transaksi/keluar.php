<?php
include '../config/koneksi.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

if (isset($_GET['selesaikan'])) {
    $id = $_GET['selesaikan'];
    $tanggal_keluar = date('Y-m-d');
    mysqli_query($conn, "UPDATE transaksi SET status='Keluar', tanggal_keluar='$tanggal_keluar' WHERE id='$id'");
    header("Location: keluar.php?msg=selesai");
    exit;
}

$query = mysqli_query($conn, "SELECT t.*, k.nama FROM transaksi t 
                              JOIN konsumen k ON t.id_konsumen = k.id 
                              WHERE t.status = 'Masuk'");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Transaksi Keluar</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .keluar-page {
        background-image: url("../assets/img/keluar.jpg");
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        min-height: 100vh;
        padding: 40px;
        font-family: "Segoe UI", sans-serif;
        margin: 0;
        animation: fadeIn 1s ease-in-out;
    }

    h2 {
        text-align: center;
        color: white;
        margin-bottom: 30px;
        text-shadow: 1px 1px 4px rgba(0,0,0,0.6);
        font-size: 32px;
        animation: fadeIn 1.2s ease-in-out;
    }

    .table-container {
        background: rgba(255, 255, 255, 0.92);
        border-radius: 12px;
        padding: 25px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.2);
        overflow-x: auto;
        animation: fadeIn 1.4s ease-in-out;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
        font-size: 15px;
    }

    th, td {
        padding: 12px 15px;
        border-bottom: 1px solid #ddd;
        text-align: center;
    }

    th {
        background-color: rgb(177, 146, 230);
        color: white;
        letter-spacing: 1px;
    }

    tr {
        transition: background-color 0.3s ease;
    }

    tr:hover {
        background-color: rgba(240, 240, 240, 0.9);
    }

    .button {
        background-color: rgb(177, 146, 230);
        color: white;
        padding: 8px 14px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        text-decoration: none;
        font-weight: bold;
        transition: all 0.3s ease;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    .button:hover {
        background-color: rgb(160, 125, 221);
        transform: scale(1.05);
        box-shadow: 0 6px 14px rgba(0,0,0,0.15);
    }

    .back-btn {
        margin-top: 30px;
        text-align: center;
    }

    .success {
        background: #eafaf1;
        color: #2ecc71;
        padding: 12px;
        margin-bottom: 20px;
        border-left: 6px solid #2ecc71;
        border-radius: 6px;
        max-width: 500px;
        margin-left: auto;
        margin-right: auto;
        font-weight: bold;
        text-align: center;
        animation: fadeIn 1.3s ease-in-out;
    }
</style>

</head>
<body class="keluar-page">

<h2>🧺 Transaksi Keluar</h2>

<?php if (isset($_GET['msg']) && $_GET['msg'] == 'selesai'): ?>
    <div class="success">✅ Transaksi berhasil diselesaikan!</div>
<?php endif; ?>

<div class="table-container">
    <table>
        <tr>
            <th>No</th>
            <th>Konsumen</th>
            <th>Tanggal Masuk</th>
            <th>Berat</th>
            <th>Total Harga</th>
            <th>Aksi</th>
        </tr>

        <?php $no = 1; while ($row = mysqli_fetch_assoc($query)) : ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $row['nama'] ?></td>
            <td><?= $row['tanggal_masuk'] ?></td>
            <td><?= $row['berat'] ?> kg</td>
            <td>Rp <?= number_format($row['total_harga']) ?></td>
            <td>
                <a href="?selesaikan=<?= $row['id'] ?>" class="button" onclick="return confirm('Selesaikan transaksi ini?')">Selesaikan</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<div class="back-btn">
    <a href="../dashboard.php" class="button">⬅️ Kembali ke Dashboard</a>
</div>

</body>
</html>
