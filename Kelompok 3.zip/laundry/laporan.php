<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

include 'config/koneksi.php';

$masuk = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM transaksi WHERE status = 'Masuk'"));
$keluar = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM transaksi WHERE status = 'Keluar'"));
$kiloan = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM transaksi"));
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Status Penjualan</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="dashboard-container">
    <div class="sidebar">
        <h3 class="brand-title">🧺 No.1 Laundry Express di Indonesia</h3>
        <h3 class="subtitle-korean">존의 최고의 세탁소</h3>
        <a href="dashboard.php" class="button animate-wobble">🏠 Kembali ke Dashboard</a>
    </div>

    <div class="main-content">
        <h2>Status Penjualan</h2>
        <div style="background-color: rgba(255,255,255,0.9); border-radius: 12px; padding: 20px;">
            <canvas id="penjualanChart" width="400" height="200"></canvas>
        </div>
    </div>
</div>

<script>
const ctx = document.getElementById('penjualanChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Masuk', 'Keluar', 'Kiloan'],
        datasets: [{
            label: 'Jumlah Transaksi',
            data: [<?= $masuk ?>, <?= $keluar ?>, <?= $kiloan ?>],
            backgroundColor: ['#3498db', '#e67e22', '#9b59b6'],
            borderRadius: 8
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false },
            title: {
                display: true,
                text: 'Statistik Penjualan Laundry',
                font: { size: 18 }
            }
        },
        scales: { y: { beginAtZero: true } }
    }
});
</script>
</body>
</html>
