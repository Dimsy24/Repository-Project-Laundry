<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

include 'config/koneksi.php';

// Hitung jumlah transaksi
$masuk  = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM transaksi WHERE status = 'Masuk'"));
$keluar = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM transaksi WHERE status = 'Keluar'"));
$kiloan = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM transaksi"));
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Status Penjualan</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .subtitle-korean {
            font-size: 14px;
            font-weight: normal;
            color: #ffffff;
            margin-top: -10px;
        }
        .chart-container {
            background-color: rgba(255, 255, 255, 0.95);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            max-width: 600px;
            margin: auto;
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <div class="sidebar">
        <h3 class="brand-title">🧺 Laundry Day</h3>
        <h3 class="subtitle-korean">It's Laundry Day!</h3>
        <a href="dashboard.php" class="button animate-wobble">🏠 Kembali ke Dashboard</a>
    </div>

    <div class="main-content">
        <h2>Status Penjualan</h2>
        <div class="chart-container">
            <canvas id="penjualanChart" width="400" height="200"></canvas>
        </div>
    </div>
</div>

<script>
const ctx = document.getElementById('penjualanChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Masuk', 'Keluar', 'Kiloan'],
        datasets: [{
            label: 'Jumlah Transaksi',
            data: [<?= $masuk ?>, <?= $keluar ?>, <?= $kiloan ?>],
            backgroundColor: ['#C4E1F6', '#FF9D3D', '#FFBD73'],
            borderRadius: 8
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false },
            title: {
                display: true,
                text: 'Statistik Penjualan Laundry',
                font: { size: 18 }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    precision: 0
                }
            }
        }
    }
});
</script>
</body>
</html>
