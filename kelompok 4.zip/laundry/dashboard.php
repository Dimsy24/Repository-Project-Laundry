<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

include 'config/koneksi.php';

$konsumen = mysqli_query($conn, "SELECT * FROM konsumen");
$jumlah_konsumen = mysqli_num_rows($konsumen);

$masuk = mysqli_query($conn, "SELECT * FROM transaksi WHERE status = 'Masuk'");
$jumlah_masuk = mysqli_num_rows($masuk);

$keluar = mysqli_query($conn, "SELECT * FROM transaksi WHERE status = 'Keluar'");
$jumlah_keluar = mysqli_num_rows($keluar);

$jumlah_kiloan = mysqli_query($conn, "SELECT * FROM transaksi");
$total_kiloan = mysqli_num_rows($jumlah_kiloan);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    
</head>
<body>

<div class="dashboard-container">

    <div class="sidebar">
        <h3 class="brand-title">🧺 Laundry Day</h3>
        <h3 class="subtitle-korean"> It's Laundry Day!</h3>
        <p>Hai, <?= $_SESSION['user']; ?></p>
        <a href="konsumen/index.php" class="button animate-wobble">👤 Data Konsumen</a>
        <a href="transaksi/masuk.php" class="button animate-wobble">📥 Transaksi Masuk</a>
        <a href="transaksi/keluar.php" class="button animate-wobble">📤 Transaksi Keluar</a>
        <a href="kiloan/list.php" class="button animate-wobble">📋 Daftar Kiloan</a>
        <a href="laporan.php" class="button animate-wobble">📊 Status Penjualan</a>
        <a href="logout.php" class="button animate-wobble" >🚪 Logout</a>
    </div>

    <div class="main-content">
        <h2>Dashboard</h2>

        <div class="stat-cards">
            <div class="card konsumen">
    <h3>Jumlah Konsumen</h3>
    <p><?= $jumlah_konsumen ?></p>
</div>
<div class="card masuk">
    <h3>Transaksi Masuk</h3>
    <p><?= $jumlah_masuk ?></p>
</div>
<div class="card keluar">
    <h3>Transaksi Keluar</h3>
    <p><?= $jumlah_keluar ?></p>
</div>
<div class="card kiloan">
    <h3>Jumlah Kiloan</h3>
    <p><?= $total_kiloan ?></p>
</div>
        </div>

        <a href="konsumen/index.php" class="button animate-wobble">➕ Tambah Konsumen</a>
<div style="margin-top: 30px; text-align: center;">
</div>
    </div>

</div>

</body>
</html>
