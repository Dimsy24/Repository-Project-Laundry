<?php
include '../config/koneksi.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

$query = mysqli_query($conn, "
    SELECT t.*, k.nama 
    FROM transaksi t 
    JOIN konsumen k ON t.konsumen_id = k.id 
    WHERE t.status = 'Masuk'
");

if (!$query) {
    die("Query error: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Daftar Transaksi Masuk</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<h2>Daftar Transaksi Masuk</h2>

<table border="1" cellpadding="8">
    <tr>
        <th>No</th>
        <th>Konsumen</th>
        <th>Tanggal Masuk</th>
        <th>Berat</th>
        <th>Harga/Kg</th>
        <th>Total</th>
        <th>Status</th>
        <th>Aksi</th>
    </tr>

    <?php $no = 1; while ($row = mysqli_fetch_assoc($query)): ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= $row['nama'] ?></td>
        <td><?= $row['tgl_masuk'] ?></td>
        <td><?= $row['berat'] ?> kg</td>
        <td>Rp <?= number_format($row['harga_per_kg']) ?></td>
        <td>Rp <?= number_format($row['total_harga']) ?></td>
        <td><?= $row['status'] ?></td>
        <td>
            <a href="keluar.php?id=<?= $row['id'] ?>" onclick="return confirm('Tandai transaksi ini sebagai selesai?')">Selesaikan</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<a href="../dashboard.php">⬅️ Kembali ke Dashboard</a>
</body>
</html>
