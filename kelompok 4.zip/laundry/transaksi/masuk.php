<?php
include '../config/koneksi.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

// Proses simpan transaksi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $konsumen_id = $_POST['id_konsumen'];
    $tgl_masuk = $_POST['tanggal_masuk'];
    $berat = $_POST['berat'];
    $harga_per_kg = $_POST['harga_per_kg'];
    $total_harga = $berat * $harga_per_kg;

    if ($berat <= 0 || $harga_per_kg <= 0) {
        die("Berat dan harga tidak boleh nol.");
    }

    $query = "INSERT INTO transaksi (konsumen_id, tgl_masuk, berat, harga_per_kg, total_harga, status) 
              VALUES ('$konsumen_id', '$tgl_masuk', '$berat', '$harga_per_kg', '$total_harga', 'Masuk')";

    $result = mysqli_query($conn, $query);
    if (!$result) {
        die("Gagal menyimpan transaksi: " . mysqli_error($conn));
    }

    header("Location: masuk.php?msg=sukses");
    exit;
}

// Ambil data konsumen untuk form
$konsumen = mysqli_query($conn, "SELECT * FROM konsumen");

// Ambil data transaksi masuk
$transaksi_masuk = mysqli_query($conn, "
    SELECT t.*, k.nama 
    FROM transaksi t 
    JOIN konsumen k ON t.konsumen_id = k.id 
    WHERE t.status = 'Masuk'
");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Transaksi Masuk</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<h2>Input Transaksi Masuk</h2>

<?php if (isset($_GET['msg']) && $_GET['msg'] === 'sukses'): ?>
    <p style="color:green;">Transaksi berhasil ditambahkan.</p>
<?php endif; ?>

<form method="post" class="transaksi-form">
    <label for="id_konsumen">Nama Konsumen</label><br>
    <select name="id_konsumen" required>
        <option value="">-- Pilih Konsumen --</option>
        <?php while ($row = mysqli_fetch_assoc($konsumen)): ?>
            <option value="<?= $row['id'] ?>"><?= $row['nama'] ?></option>
        <?php endwhile; ?>
    </select><br><br>

    <label for="tanggal_masuk">Tanggal Masuk</label><br>
    <input type="date" name="tanggal_masuk" required><br><br>

    <label for="berat">Berat Cucian (Kg)</label><br>
    <input type="number" step="0.1" name="berat" required><br><br>

    <label for="harga_per_kg">Harga per Kg</label><br>
    <input type="number" name="harga_per_kg" required><br><br>

    <button type="submit">Simpan Transaksi</button>
</form>

<hr>
<h2>Daftar Transaksi Masuk (Belum Selesai)</h2>
<table border="1" cellpadding="8">
    <tr>
        <th>No</th>
        <th>Konsumen</th>
        <th>Tanggal Masuk</th>
        <th>Berat</th>
        <th>Harga/Kg</th>
        <th>Total</th>
        <th>Status</th>
        <th>Aksi</th>
    </tr>
    <?php $no = 1; while ($row = mysqli_fetch_assoc($transaksi_masuk)): ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td><?= $row['tgl_masuk'] ?></td>
        <td><?= $row['berat'] ?> kg</td>
        <td>Rp <?= number_format($row['harga_per_kg']) ?></td>
        <td>Rp <?= number_format($row['total_harga']) ?></td>
        <td><?= $row['status'] ?></td>
        <td>
            <a href="keluar_aksi.php?id=<?= $row['id'] ?>" onclick="return confirm('Tandai transaksi ini sebagai selesai?')">Selesaikan</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<div class="dashboard-button-wrapper">
    <a href="../dashboard.php" class="button dashboard-button">⬅️ Kembali ke Dashboard</a>
</div>

</body>
</html>
