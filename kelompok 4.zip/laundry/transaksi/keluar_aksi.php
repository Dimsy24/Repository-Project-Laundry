<?php
include '../config/koneksi.php';
session_start();

// Pastikan user sudah login
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

// Validasi ID transaksi
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID tidak valid.");
}

$id = (int) $_GET['id'];
$tgl_keluar = date("Y-m-d");

// Update transaksi: status menjadi 'Keluar' dan set tanggal keluar
$query = "UPDATE transaksi 
          SET status='Keluar', tgl_keluar='$tgl_keluar' 
          WHERE id=$id AND status='Masuk'";

$result = mysqli_query($conn, $query);

if ($result) {
    header("Location: ../kiloan/list.php?msg=selesai");
    exit;
} else {
    die("Gagal menyelesaikan transaksi: " . mysqli_error($conn));
}
?>
