<?php
include '../config/koneksi.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

// Ambil semua transaksi status 'Keluar'
$query = mysqli_query($conn, "
    SELECT t.*, k.nama 
    FROM transaksi t
    JOIN konsumen k ON t.konsumen_id = k.id
    WHERE t.status = 'Keluar'
    ORDER BY t.tgl_keluar DESC
");

if (!$query) {
    die("Gagal mengambil data: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Transaksi Keluar (Selesai)</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<h2>Daftar Transaksi Keluar (Selesai)</h2>

<?php if (isset($_GET['msg']) && $_GET['msg'] == 'hapus_sukses'): ?>
    <p class="success">Transaksi berhasil dihapus.</p>
<?php endif; ?>

<table border="1" cellpadding="8">
    <tr>
        <th>No</th>
        <th>Nama Konsumen</th>
        <th>Tanggal Masuk</th>
        <th>Tanggal Keluar</th>
        <th>Berat</th>
        <th>Total Harga</th>
        <th>Status</th>
        <th>Aksi</th>
    </tr>
    <?php $no = 1; while ($row = mysqli_fetch_assoc($query)): ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td><?= $row['tgl_masuk'] ?></td>
        <td><?= $row['tgl_keluar'] ?></td>
        <td><?= $row['berat'] ?> kg</td>
        <td>Rp <?= number_format($row['total_harga']) ?></td>
        <td><?= $row['status'] ?></td>
        <td>
            <a href="hapus_transaksi.php?id=<?= $row['id'] ?>" onclick="return confirm('Yakin ingin menghapus transaksi ini?')">Hapus</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<div class="dashboard-button-wrapper">
    <a href="../dashboard.php" class="button dashboard-button">⬅️ Kembali ke Dashboard</a>
</div>

</body>
</html>
