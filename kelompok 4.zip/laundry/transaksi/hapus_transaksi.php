<?php
include '../config/koneksi.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID tidak valid.");
}

$id = (int) $_GET['id'];

// Pastikan hanya transaksi yang sudah keluar yang boleh dihapus
$cek = mysqli_query($conn, "SELECT * FROM transaksi WHERE id=$id AND status='Keluar'");
if (mysqli_num_rows($cek) === 0) {
    die("Transaksi tidak ditemukan atau belum selesai.");
}

mysqli_query($conn, "DELETE FROM transaksi WHERE id=$id");

header("Location: ../kiloan/list.php?msg=hapus_sukses");
exit;
?>
