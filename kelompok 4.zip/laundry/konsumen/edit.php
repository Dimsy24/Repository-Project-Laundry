<?php
include '../config/koneksi.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM konsumen WHERE id = $id");
$data = mysqli_fetch_assoc($result);

if (isset($_POST['update'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telp = $_POST['telp'];

    mysqli_query($conn, "UPDATE konsumen SET nama='$nama', alamat='$alamat', telp='$telp' WHERE id=$id");
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Konsumen</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body style="background-color: #f7f8fa; font-family: 'Segoe UI', sans-serif; padding: 30px;">

    <div style="max-width: 500px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
        <h2 style="color: #22a2ab; text-align: center;">✏️ Edit Konsumen</h2>
        <form method="post">
            <label>Nama:</label><br>
            <input type="text" name="nama" value="<?= $data['nama']; ?>" required style="width: 100%; padding: 10px; margin-bottom: 15px; border-radius: 6px; border: 1px solid #ccc;"><br>
            <label>Alamat:</label><br>
            <input type="text" name="alamat" value="<?= $data['alamat']; ?>" required style="width: 100%; padding: 10px; margin-bottom: 15px; border-radius: 6px; border: 1px solid #ccc;"><br>
            <label>Telp:</label><br>
            <input type="text" name="telp" value="<?= $data['telp']; ?>" required style="width: 100%; padding: 10px; margin-bottom: 20px; border-radius: 6px; border: 1px solid #ccc;"><br>

            <button type="submit" name="update" class="button animate-wobble" style="background-color: #3498db; color: white;">💾 Simpan Perubahan</button>
            <a href="index.php" class="button animate-wobble" style="background-color: #e0e0e0; color: black; margin-left: 10px;">⬅️ Kembali</a>
        </form>
    </div>

</body>
</html>
