<?php
include '../config/koneksi.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID tidak valid.");
}

$id = (int) $_GET['id'];

$query = "SELECT * FROM konsumen WHERE id = $id";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query error: " . mysqli_error($conn));
}

$row = mysqli_fetch_assoc($result);

// Cek apakah konsumen punya transaksi terkait
$cek = mysqli_query($conn, "SELECT COUNT(*) AS total FROM transaksi WHERE konsumen_id = $id");
$data = mysqli_fetch_assoc($cek);

if ($data['total'] > 0) {
    header("Location: index.php?msg=terpakai");
    exit;
}

// Hapus konsumen
mysqli_query($conn, "DELETE FROM konsumen WHERE id = $id");

header("Location: index.php?msg=hapus_sukses");
exit;
?>
