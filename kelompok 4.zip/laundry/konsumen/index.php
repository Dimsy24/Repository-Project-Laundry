<?php
include '../config/koneksi.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

$result = mysqli_query($conn, "SELECT * FROM konsumen");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Konsumen</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            background:rgb(14, 43, 71);
            font-family: "Segoe UI", sans-serif;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color:rgb(161, 165, 168);
            margin-bottom: 30px;
        }

        .konsumen-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .konsumen-card {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            padding: 20px;
            transition: transform 0.3s;
        }

        .konsumen-card:hover {
            transform: translateY(-5px);
        }

        .konsumen-card h3 {
            margin: 0 0 10px;
            color: #34495e;
        }

        .konsumen-card p {
            margin: 5px 0;
            color: #555;
        }

        .card-buttons {
            margin-top: 10px;
            display: flex;
            gap: 10px;
        }

        .button {
            padding: 8px 14px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: 0.3s;
        }

        .button.edit {
            background: #27ae60;
            color: white;
        }

        .button.edit:hover {
            background: #219150;
        }

        .button.delete {
            background: #e74c3c;
            color: white;
        }

        .button.delete:hover {
            background: #c0392b;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .top-bar a {
            background-color: #3498db;
            color: white;
        }

        .top-bar a:hover {
            background-color: #2980b9;
        }

        .back-btn {
            margin-top: 30px;
        }

        .success-message, .error-message {
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .success-message {
            background-color: #eafaf1;
            color: #2ecc71;
            border-left: 5px solid #2ecc71;
        }

        .error-message {
            background-color: #fdecea;
            color: #e74c3c;
            border-left: 5px solid #e74c3c;
        }
    </style>
</head>
<body>

    <h2>📋 Data Konsumen</h2>

    <?php if (isset($_GET['msg'])): ?>
        <?php if ($_GET['msg'] == 'terpakai'): ?>
            <div class="error-message">❌ Gagal menghapus! Konsumen ini masih memiliki transaksi.</div>
        <?php elseif ($_GET['msg'] == 'hapus_sukses'): ?>
            <div class="success-message">✅ Data konsumen berhasil dihapus.</div>
        <?php endif; ?>
    <?php endif; ?>

    <div class="top-bar">
        <a href="tambah.php" class="button animate-wobble">➕ Tambah Konsumen</a>

    </div>

    <div class="konsumen-container">
        <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) : ?>
            <div class="konsumen-card">
                <h3><?= $row['nama']; ?></h3>
                <p>📍 <?= $row['alamat']; ?></p>
                <p>📞 <?= $row['telp']; ?></p>
                <div class="card-buttons">
                    <a href="edit.php?id=<?= $row['id'] ?>" class="button edit animate-wobble">✏️ Edit</a>
                    <a href="hapus.php?id=<?= $row['id'] ?>" class="button delete animate-wobble" onclick="return confirm('Yakin ingin hapus?')">🗑️ Hapus</a>

                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <div class="back-btn">
        <a href="../dashboard.php" class="button animate-wobble">⬅️ Kembali ke Dashboard</a>

    </div>

</body>
</html>
