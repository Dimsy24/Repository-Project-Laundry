<?php
include '../config/koneksi.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

if (isset($_POST['simpan'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telp = $_POST['telp'];

    // Generate kode_konsumen otomatis
    $result = mysqli_query($conn, "SELECT MAX(id) as max_id FROM konsumen");
    $data = mysqli_fetch_assoc($result);
    $next_id = $data['max_id'] + 1;
    $kode_konsumen = 'LAUNDRY-' . str_pad($next_id, 3, '0', STR_PAD_LEFT);

    // Insert data lengkap
    $query = "INSERT INTO konsumen (kode_konsumen, nama, alamat, telp) 
              VALUES ('$kode_konsumen', '$nama', '$alamat', '$telp')";

    if (mysqli_query($conn, $query)) {
        header("Location: index.php");
        exit;
    } else {
        die("Gagal menyimpan data: " . mysqli_error($conn));
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Tambah Konsumen</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .form-container {
            max-width: 500px;
            background-color: #ffffff;
            margin: 50px auto;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #2a497f;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 6px;
            transition: 0.3s;
        }

        input[type="text"]:focus {
            border-color: #3498db;
            outline: none;
            box-shadow: 0 0 5px rgba(52, 152, 219, 0.4);
        }

        .button.animate-wobble {
            display: inline-block;
            padding: 10px 20px;
            font-weight: bold;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: 0.3s;
            text-decoration: none;
        }

        .button.animate-wobble:hover {
            animation: wobble 0.4s ease;
            background-color: #2980b9;
        }

        .back-link {
            display: inline-block;
            margin-top: 15px;
            color: #3498db;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        @keyframes wobble {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-3px); }
            50% { transform: translateX(3px); }
            75% { transform: translateX(-2px); }
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Tambah Konsumen</h2>
    <form method="post">
        <label for="nama">Nama</label>
        <input type="text" name="nama" id="nama" required>

        <label for="alamat">Alamat</label>
        <input type="text" name="alamat" id="alamat" required>

        <label for="telp">Telepon</label>
        <input type="text" name="telp" id="telp" required>

        <button type="submit" name="simpan" class="button animate-wobble">💾 Simpan</button>
    </form>
    <br>
    <a href="index.php" class="button animate-wobble">← Kembali ke Dashboard</a>
</div>

</body>
</html>
