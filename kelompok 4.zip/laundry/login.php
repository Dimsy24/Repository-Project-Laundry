<?php
session_start();
include 'config/koneksi.php';

$error = false;

if (isset($_POST['login'])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM users WHERE username='$user' AND password='$pass'");
    $data = mysqli_fetch_array($query);

    if ($data) {
        $_SESSION['user'] = $data['username'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = true;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            margin: 0;
            font-family: 'Great Vibes', cursive;
            background: linear-gradient(135deg,rgb(170, 154, 111),rgb(177, 135, 58));
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-box {
    background: rgba(255, 255, 255, 0.3);
    padding: 30px 25px;
    border-radius: 16px;
    backdrop-filter: blur(10px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
    text-align: center;
    width: 100%;
    max-width: 340px;
    box-sizing: border-box;
}


        .login-box h2 {
            color: #fff;
            margin-bottom: 20px;
        }

        .input-group {
            position: relative;
            margin-bottom: 20px;
        }

        .input-group input {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 8px;
            background-color: #f0f4ff;
            font-size: 14px;
            box-sizing: border-box;
            outline: none;
        }

        .input-group i {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #666;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: 0.3s;
        }

        button:hover {
            background-color: #45a049;
        }
        
    </style>
</head>
<body>

<div class="login-box">
    <h2>🧺 Login Laundry</h2>
    <form method="post">
        <div class="input-group">
            <input type="text" name="username" placeholder="Username" required>
            <i class="fas fa-user"></i>
        </div>
        <div class="input-group">
            <input type="password" name="password" placeholder="Password" required>
            <i class="fas fa-lock"></i>
        </div>
        <button type="submit" name="login">Login</button>
    </form>
</div>

<?php if ($error): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Login Gagal',
        text: 'Username atau Password salah!',
        confirmButtonColor: '#d33'
    });
</script>
<?php endif; ?>

<!-- Font Awesome for icons -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
