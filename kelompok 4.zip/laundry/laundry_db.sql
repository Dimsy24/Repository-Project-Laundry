-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 09, 2025 at 08:41 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laundry_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `konsumen`
--

CREATE TABLE `konsumen` (
  `id` int(11) NOT NULL,
  `kode_konsumen` varchar(20) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `telp` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `konsumen`
--

INSERT INTO `konsumen` (`id`, `kode_konsumen`, `nama`, `alamat`, `telp`, `created_at`) VALUES
(5, 'LAUNDRY-005', 'nazwa', 'Jl. Merpati No. 1000000000000', '08123456789', '2025-07-08 17:54:40'),
(7, 'LAUNDRY-006', 'inayah', 'jalan sidomulyo', '82387338724', '2025-07-08 18:41:35'),
(8, 'LAUNDRY-008', 'annisa', 'jalan sidomulyo', '08123456000', '2025-07-08 18:41:43'),
(9, 'LAUNDRY-009', 'astri', 'jalan mekar', '081234568', '2025-07-08 21:06:48'),
(10, 'LAUNDRY-010', 'putri', 'gang buntu', '1823625251', '2025-07-08 21:08:38'),
(11, 'LAUNDRY-011', 'dewi', 'jalan ikan duyung', '92725241', '2025-07-08 21:08:56');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `konsumen_id` int(11) NOT NULL,
  `jenis_laundry` enum('Kiloan','Satuan') DEFAULT 'Kiloan',
  `berat` float DEFAULT 0,
  `harga_per_kg` decimal(10,2) NOT NULL,
  `total_harga` decimal(10,2) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `tgl_keluar` date DEFAULT NULL,
  `status` enum('Masuk','Keluar') DEFAULT 'Masuk',
  `catatan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `konsumen_id`, `jenis_laundry`, `berat`, `harga_per_kg`, `total_harga`, `tgl_masuk`, `tgl_keluar`, `status`, `catatan`, `created_at`) VALUES
(9, 5, 'Kiloan', 5, 3000.00, 15000.00, '2025-07-09', '2025-07-08', 'Keluar', NULL, '2025-07-08 21:06:10'),
(10, 8, 'Kiloan', 8, 4000.00, 32000.00, '2025-07-08', '2025-07-08', 'Keluar', NULL, '2025-07-08 21:06:26'),
(11, 7, 'Kiloan', 3, 10000.00, 30000.00, '2025-07-07', '2025-07-08', 'Keluar', NULL, '2025-07-08 21:09:23'),
(12, 10, 'Kiloan', 4, 7500.00, 30000.00, '2025-07-07', NULL, 'Masuk', NULL, '2025-07-08 21:09:46'),
(13, 11, 'Kiloan', 34, 3000.00, 102000.00, '2025-07-04', NULL, 'Masuk', NULL, '2025-07-08 21:10:07'),
(14, 11, 'Kiloan', 6, 5500.00, 33000.00, '2025-07-09', NULL, 'Masuk', NULL, '2025-07-08 21:10:34');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff') DEFAULT 'staff',
  `nama_lengkap` varchar(100) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `nama_lengkap`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', '12345', 'admin', 'Administrator', NULL, '2025-07-08 17:34:55', '2025-07-08 17:53:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `konsumen`
--
ALTER TABLE `konsumen`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_konsumen` (`kode_konsumen`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `konsumen_id` (`konsumen_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `konsumen`
--
ALTER TABLE `konsumen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`konsumen_id`) REFERENCES `konsumen` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
