<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Happy Laundry</title>
  <link rel="stylesheet" href="assets/css/bootstrap.css" type="text/css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
  <script type="text/javascript" src="assets/js/jquery.js"></script>
  <script type="text/javascript" src="assets/js/bootstrap.js"></script>

  <style>
    body {
      margin: 0;
      height: 100vh;
      font-family: 'Poppins', sans-serif;
      background-image: url('assets/image/awan.png');
      background-repeat: repeat;
      background-size: contain;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
    }

    h2.brand-title {
      font-size: 36px;
      margin-bottom: 25px;
      color: white;
      text-shadow: 2px 2px 4px rgba(0, 123, 255, 0.3);
      animation: fadeInPop 0.6s ease-out forwards;
      transform: scale(0.95);
      transition: transform 0.3s ease, text-shadow 0.3s ease;
    }

    h2.brand-title:hover {
      transform: scale(1.03);
      text-shadow: 4px 4px 10px rgba(93, 182, 255, 0.6);
    }

    .login-box {
      width: 100%;
      max-width: 400px;
      background-color: rgba(93, 182, 255, 0.95);
      border-radius: 12px;
      padding: 25px 20px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
      animation: fadeSlideUp 0.5s ease-out 0.2s forwards;
      opacity: 0;
      transform: translateY(20px);
    }

    .form-control {
      border-radius: 6px;
    }

    .btn-primary {
      background-color: #007bff;
      border: none;
      border-radius: 6px;
      padding: 10px;
      font-weight: bold;
      transition: background-color 0.2s ease-in-out;
    }

    .btn-primary:hover {
      background-color: #0056b3;
    }

    @keyframes fadeSlideDown {
      from {
        opacity: 0;
        transform: translateY(-10px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes fadeSlideUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes fadeOutSlideUp {
      from {
        opacity: 1;
        transform: translateY(0);
      }

      to {
        opacity: 0;
        transform: translateY(-30px);
      }
    }

    .fade-out {
      animation: fadeOutSlideUp 0.4s ease-in forwards;
    }
  </style>
</head>

<body>
  <h2 class="brand-title">HAPPY LAUNDRY</h2>

  <div class="login-box">
    <?php
    session_start();
    if (isset($_GET['pesan'])) {
      if ($_GET['pesan'] == "gagal") {
        echo "<div class='alert alert-danger'>Login gagal! Username dan password salah!</div>";
      } else if ($_GET['pesan'] == "logout") {
        echo "<div class='alert alert-info'>Anda telah berhasil logout.</div>";
      } else if ($_GET['pesan'] == "belum_login") {
        echo "<div class='alert alert-warning'>Anda harus login untuk mengakses halaman admin.</div>";
      }
    }
    ?>

    <form action="login.php" method="post">
      <div class="form-group">
        <label style="color: white;">Username</label>
        <input type="text" class="form-control" name="username" required>
      </div>
      <div class="form-group">
        <label style="color: white;">Password</label>
        <input type="password" class="form-control" name="password" required>
      </div>
      <input type="submit" class="btn btn-primary btn-block" value="Log In">
    </form>
  </div>

  <script>
    document.querySelector("form").addEventListener("submit", function(e) {
      e.preventDefault();
      const loginBox = document.querySelector(".login-box");
      const title = document.querySelector("h2");

      loginBox.classList.add("fade-out");
      title.classList.add("fade-out");

      setTimeout(() => {
        e.target.submit();
      }, 400);
    });
  </script>
</body>

</html>