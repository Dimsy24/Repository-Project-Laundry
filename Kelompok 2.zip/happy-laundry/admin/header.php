<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HAPPY LAUNDRY</title>
  <link rel="stylesheet" href="../assets/css/bootstrap.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <script type="text/javascript" src="assets/js/jquery.js"></script>
  <script type="text/javascript" src="assets/js/bootstrap.js"></script>
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Poppins', sans-serif;
      background-image: url('../assets/image/awan.png');
      background-repeat: repeat;
      background-size: contain;
    }

    @keyframes fadeInUp {
      0% {
        opacity: 0;
        transform: translateY(30px);
      }

      100% {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .animated-section {
      opacity: 0;
      animation: fadeInUp 0.2s ease-out forwards;
    }

    .navbar {
      margin-bottom: 0;

    }

    .navbar-nav>li>a {
      transition: all 0.1s ease-in-out;
      border-radius: 4px;
    }

    .navbar-nav>li>a:hover,
    .dropdown-menu>li>a:hover {
      background-color: #3399dd !important;
      color: white !important;
      box-shadow: inset 0 -3px 5px rgba(0, 0, 0, 0.2), 0 2px 5px rgba(0, 0, 0, 0.15);
      transform: translateY(-1px);
    }

    .navbar-nav>li.active>a {
      background-color: #3399dd !important;
      color: white !important;
      box-shadow: inset 0 -3px 5px rgba(0, 0, 0, 0.2), 0 2px 5px rgba(0, 0, 0, 0.15);
      transform: translateY(-1px);
    }

    .navbar-inverse {
      background-color: #5db6ff;
      border: none;
    }

    .navbar-inverse .navbar-brand,
    .navbar-inverse .navbar-nav>li>a,
    .navbar-inverse .navbar-text {
      color: #fff !important;
    }

    .dropdown-menu {
      background-color: #f8f8f8;
    }

    .dropdown-menu>li>a {
      color: #333;
    }

    .dropdown-menu>li>a:hover {
      background-color: #e8f0ff;
      color: #000;
    }

    .container {
      margin-top: 30px;
    }

    .dashboard-box {
      background-color: #3399dd;
      border-radius: 20px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
      padding: 20px;
      margin-bottom: 20px;
      color: white;
      animation: fadeInUp 0.2s ease-out both;
    }

    .text-stroke {
      color: white;
      text-shadow:
        -3px -3px 0 black,
        -3px 0px 0 black,
        -3px 3px 0 black,
        0px -3px 0 black,
        0px 3px 0 black,
        3px -3px 0 black,
        3px 0px 0 black,
        3px 3px 0 black;
    }

    footer {
      text-align: center;
      padding: 20px;
      color: #888;
      font-size: 14px;
    }
  </style>
</head>

<body>
  <?php
  session_start();
  if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
  }

  $halaman = basename($_SERVER['PHP_SELF']);
  ?>

  <nav class="navbar navbar-inverse" style="border-radius: 0px;">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php">HAPPY LAUNDRY</a>
      </div>
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li class="<?= $halaman == 'index.php' ? 'active' : '' ?>"><a href="index.php"><i class="glyphicon glyphicon-home"></i> Dashboard</a></li>
          <li class="<?= $halaman == 'pelanggan.php' ? 'active' : '' ?>"><a href="pelanggan.php"><i class="glyphicon glyphicon-user"></i> Pelanggan</a></li>
          <li class="<?= $halaman == 'transaksi.php' ? 'active' : '' ?>"><a href="transaksi.php"><i class="glyphicon glyphicon-random"></i> Transaksi</a></li>
          <li class="<?= $halaman == 'laporan.php' ? 'active' : '' ?>"><a href="laporan.php"><i class="glyphicon glyphicon-list-alt"></i> Laporan</a></li>
          <li class="dropdown <?= in_array($halaman, ['harga.php', 'ganti_password.php']) ? 'active' : '' ?>">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
              <i class="glyphicon glyphicon-wrench"></i> Pengaturan <span class="caret"></span>
            </a>
            <ul class="dropdown-menu">
              <li class="<?= $halaman == 'harga.php' ? 'active' : '' ?>"><a href="harga.php"><i class="glyphicon glyphicon-usd"></i> Pengaturan Harga</a></li>
              <li class="<?= $halaman == 'ganti_password.php' ? 'active' : '' ?>"><a href="ganti_password.php"><i class="glyphicon glyphicon-lock"></i> Ganti Password</a></li>
            </ul>
          </li>
          <li><a href="logout.php"><i class="glyphicon glyphicon-log-out"></i> Log Out</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li>
            <p class="navbar-text" style="color: white;">Halo, <b style="color: white;"><?php echo $_SESSION['username']; ?></b></p>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <?php if ($halaman == "index.php") { ?>
    <div class="container animated-section">
      <div class="dashboard-box text-center animated-section">
        <h1 class="text-stroke"><strong>Selamat datang di Happy Laundry!</strong></h1>
        <img src="../assets/image/mc.png" alt="Laundry Icon" style="width: 140px; height: auto; margin-bottom: 15px;">
        <img src="../assets/image/kl.png" alt="Laundry Icon" style="width: 300px; height: auto; margin-bottom: 15px;">
        <img src="../assets/image/mc.png" alt="Laundry Icon" style="width: 140px; height: auto; margin-bottom: 15px;">
      </div>
    </div>
  <?php } ?>

  <?php include 'footer.php'; ?>

  <script>
    $(document).ready(function() {
      $("a").not('[target="_blank"]').on("click", function(e) {
        const href = $(this).attr("href");

        if (href && href !== "#" && !$(this).hasClass("dropdown-toggle")) {
          e.preventDefault();
          window.location.href = href;
        }
      });
    });
  </script>
</body>

</html>