<?php include 'header.php'; ?>
<?php include '../koneksi.php'; ?>

<style>
  .panel-custom {
    border-radius: 10px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    background-color: #fefefe;
    animation: fadeInUp 0.7s ease-out forwards;
    opacity: 0;
    margin-top: 50px;
  }

  .panel-custom .panel-heading {
    background-color: #3399dd;
    color: white;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    padding: 15px 25px;
  }

  .panel-custom .panel-body {
    padding: 25px;
  }

  .btn-primary-custom {
    background-color: #3399dd;
    border-color: #2c89c6;
    color: white;
    transition: 0.3s ease;
    box-shadow: 0 4px 0 #2c89c6;
  }

  .btn-primary-custom:hover {
    background-color: #2c89c6;
    border-color: #2c89c6;
  }

  .btn-info-custom {
    background-color: #17a2b8;
    border-color: #138496;
    color: white;
  }

  .btn-info-custom:hover {
    background-color: #138496;
  }

  table.table-bordered th {
    background-color: #3399dd;
    color: white;
    text-align: center;
  }

  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(30px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
</style>

<div class="container">
  <div class="col-md-8 col-md-offset-2">
    <div class="panel panel-custom">
      <div class="panel-heading">
        <h4>Edit Transaksi Laundry</h4>
      </div>
      <div class="panel-body">
        <div class="clearfix"></div>
        <br>

        <?php
        $id = $_GET['id'];
        $transaksi = mysqli_query($koneksi, "SELECT * FROM transaksi WHERE transaksi_id='$id'");
        $pakaian = mysqli_query($koneksi, "SELECT * FROM pakaian WHERE pakaian_transaksi='$id'");
        while ($t = mysqli_fetch_array($transaksi)) {
        ?>
          <form method="post" action="transaksi_update.php">
            <input type="hidden" name="id" value="<?php echo $t['transaksi_id']; ?>">

            <div class="form-group">
              <label>Pelanggan</label>
              <?php
              $pelanggan = mysqli_query($koneksi, "SELECT * FROM pelanggan WHERE pelanggan_id='$t[transaksi_pelanggan]'");
              $p = mysqli_fetch_array($pelanggan);
              ?>
              <input type="text" id="pelanggan" class="form-control" value="<?= $p['pelanggan_nama'] ?>" placeholder="Masukkan nama pelanggan" required>
              <input type="hidden" name="pelanggan" id="pelanggan_id" value="<?php echo $t['transaksi_pelanggan']; ?>">
            </div>

            <div class="form-group">
              <label>Berat (Kg)</label>
              <input type="number" class="form-control" name="berat" required value="<?php echo $t['transaksi_berat']; ?>">
            </div>

            <div class="form-group">
              <label>Layanan</label>
              <select class="form-control" name="layanan" required>
                <option value="">- Pilih Layanan -</option>
                <option value="Cuci Saja" <?= $t['transaksi_layanan'] == 'Cuci Saja' ? 'selected' : '' ?>>Cuci Saja - Rp4.000</option>
                <option value="Setrika Saja" <?= $t['transaksi_layanan'] == 'Setrika Saja' ? 'selected' : '' ?>>Setrika Saja - Rp4.000</option>
                <option value="Cuci & Setrika" <?= $t['transaksi_layanan'] == 'Cuci & Setrika' ? 'selected' : '' ?>>Cuci & Setrika - Rp6.000</option>
                <option value="Express" <?= $t['transaksi_layanan'] == 'Express' ? 'selected' : '' ?>>Express - Rp10.000</option>
              </select>
            </div>

            <div class="form-group">
              <label>Tanggal Selesai</label>
              <input type="date" class="form-control" name="tgl_selesai" required value="<?php echo $t['transaksi_tgl_selesai']; ?>">
            </div>

            <div class="form-group">
              <label>Daftar Cucian</label>
              <table class="table table-bordered" id="daftarCucian">
                <thead>
                  <tr>
                    <th>Jenis Pakaian</th>
                    <th>Jumlah</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i = 0;
                  while ($p = mysqli_fetch_array($pakaian)) { ?>
                    <tr>
                      <td><input type="text" class="form-control" name="pakaian[<?= $i ?>][jenis]" value="<?= $p['pakaian_jenis'] ?>" required></td>
                      <td><input type="number" class="form-control jumlah-pakaian" name="pakaian[<?= $i ?>][jumlah]" value="<?= $p['pakaian_jumlah'] ?>" required></td>
                      <td><button type="button" class="btn btn-danger" onclick="hapusBaris(this)">Hapus</button></td>
                    </tr>
                  <?php $i++;
                  } ?>
                </tbody>
              </table>
              <button type="button" class="btn btn-primary" id="btn-tambah">Tambah Pakaian</button>
            </div>

            <div class="form-group alert alert-info">
              <label>Status</label>
              <select class="form-control" name="status" required>
                <option value="0" <?php if ($t['transaksi_status'] == "0") echo "selected"; ?>>PROSES</option>
                <option value="1" <?php if ($t['transaksi_status'] == "1") echo "selected"; ?>>DICUCI</option>
                <option value="2" <?php if ($t['transaksi_status'] == "2") echo "selected"; ?>>SELESAI</option>
              </select>
            </div>

            <input type="submit" class="btn btn-primary-custom btn-block" value="Ubah">
          </form>
        <?php } ?>
      </div>
    </div>
  </div>
</div>

<script>
  $(document).ready(function() {
    // Ambil data pelanggan dari database
    $.ajax({
      url: 'get_pelanggan.php', // Pastikan jalur ini benar
      method: 'GET',
      dataType: 'json',
      success: function(data) {
        // Inisialisasi autocomplete
        $("#pelanggan").autocomplete({
          source: data,
          select: function(event, ui) {
            // Set ID pelanggan ke input hidden
            $("#pelanggan_id").val(ui.item.id);
          }
        });
      },
      error: function(xhr, status, error) {
        console.error("Error fetching data: " + error);
      }
    });

    let counter = document.querySelectorAll('#daftarCucian tbody tr').length;

    document.getElementById('btn-tambah').addEventListener('click', function() {
      const tableBody = document.querySelector('#daftarCucian tbody');
      const newRow = document.createElement('tr');
      newRow.innerHTML = `
            <td><input type="text" class="form-control" name="pakaian[${counter}][jenis]" placeholder="Jenis pakaian" required></td>
            <td><input type="number" class="form-control jumlah-pakaian" name="pakaian[${counter}][jumlah]" placeholder="Jumlah" required></td>
            <td><button type="button" class="btn btn-danger" onclick="hapusBaris(this)">Hapus</button></td>
        `;
      tableBody.appendChild(newRow);
      counter++;
    });

    window.hapusBaris = function(button) {
      button.closest('tr').remove();
    }
  });
</script>

<?php include 'footer.php'; ?>