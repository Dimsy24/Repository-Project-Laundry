<?php include 'header.php'; ?>
<style>
  .panel-custom {
    border-radius: 10px;
    background-color: #fefefe;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    animation: fadeInUp 0.3s ease-out forwards;
    opacity: 0;
    margin-top: 40px;
  }

  @keyframes fadeInUp {
    0% {
      opacity: 0;
      transform: translateY(30px);
    }

    100% {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .animated-section {
    opacity: 0;
    animation: fadeInUp 0.2s ease-out forwards;

  }

  .panel-custom .panel-heading {
    background-color: #3399dd;
    color: white;
    padding: 15px 25px;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
  }

  .panel-custom .panel-body {
    padding: 25px;
  }

  .btn-primary-custom {
    background-color: #3399dd;
    border-color: #2c89c6;
    color: white;
  }

  .btn-primary-custom:hover {
    background-color: #2c89c6;
  }

  .btn-print {
    margin-bottom: 15px;
  }

  .table-bordered th {
    background-color: #3399dd;
    color: white;
    text-align: center;
  }
</style>

<div class="container">
  <div class="panel panel-custom">
    <div class="panel-heading">
      <h4>Laporan</h4>
    </div>
    <div class="panel-body">
      <form action="laporan.php" method="get">
        <div class="row">
          <div class="col-md-5">
            <label>Dari Tanggal</label>
            <input type="date" name="tgl_dari" class="form-control" required>
          </div>
          <div class="col-md-5">
            <label>Sampai Tanggal</label>
            <input type="date" name="tgl_sampai" class="form-control" required>
          </div>
          <div class="col-md-2" style="margin-top: 25px;">
            <button type="submit" class="btn btn-primary-custom btn-block">Filter</button>
          </div>
        </div>
      </form>
    </div>
  </div>

  <br>

  <?php if (isset($_GET['tgl_dari']) && isset($_GET['tgl_sampai'])):
    $dari = $_GET['tgl_dari'];
    $sampai = $_GET['tgl_sampai'];
  ?>
    <div class="panel panel-custom">
      <div class="panel-heading">
        <h4>Data Laporan Laundry dari <b><?= $dari; ?></b> sampai <b><?= $sampai; ?></b></h4>
      </div>
      <div class="panel-body">
        <a target="_blank" href="cetak_print.php?dari=<?= $dari; ?>&sampai=<?= $sampai; ?>" class="btn btn-primary-custom btn-print">
          <i class="glyphicon glyphicon-print"></i> CETAK
        </a>
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th width="1%">No</th>
              <th>Invoice</th>
              <th>Tanggal</th>
              <th>Pelanggan</th>
              <th>Berat (kg)</th>
              <th>Tgl. Selesai</th>
              <th>Harga</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php
            include '../koneksi.php';
            $data = mysqli_query($koneksi, "SELECT * FROM pelanggan, transaksi 
            WHERE transaksi_pelanggan=pelanggan_id 
            AND DATE(transaksi_tgl) >= '$dari' 
            AND DATE(transaksi_tgl) <= '$sampai' 
            ORDER BY transaksi_id DESC");
            $no = 1;
            while ($d = mysqli_fetch_array($data)): ?>
              <tr>
                <td><?= $no++; ?></td>
                <td>INVOICE-<?= $d['transaksi_id']; ?></td>
                <td><?= $d['transaksi_tgl']; ?></td>
                <td><?= $d['pelanggan_nama']; ?></td>
                <td><?= $d['transaksi_berat']; ?></td>
                <td><?= $d['transaksi_tgl_selesai']; ?></td>
                <td><?= "Rp. " . number_format($d['transaksi_harga']) . " ,-"; ?></td>
                <td>
                  <?php
                  if ($d['transaksi_status'] == "0") {
                    echo "<span class='label label-warning'>PROSES</span>";
                  } else if ($d['transaksi_status'] == "1") {
                    echo "<span class='label label-info'>DICUCI</span>";
                  } else if ($d['transaksi_status'] == "2") {
                    echo "<span class='label label-success'>SELESAI</span>";
                  }
                  ?>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php endif; ?>
</div>

<?php include 'footer.php'; ?>