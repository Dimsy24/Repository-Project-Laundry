<?php include 'header.php'; ?>
<style>
  .panel-custom {
    border-radius: 10px;
    background-color: #fefefe;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    animation: fadeInUp 0.7s ease-out forwards;
    opacity: 0;
    margin-top: 40px;
  }

  .panel-custom .panel-heading {
    background-color: #3399dd;
    color: white;
    padding: 15px 25px;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
  }

  .panel-custom .panel-body {
    padding: 25px;
  }

  .btn-primary-custom {
    background-color: #3399dd;
    border-color: #2c89c6;
    color: white;
    width: 100%;
    transition: all 0.3s ease;
  }

  .btn-primary-custom:hover {
    background-color: #2c89c6;
  }

  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(30px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
</style>

<div class="container">
  <div class="col-md-6 col-md-offset-3">
    <div class="panel panel-custom">
      <div class="panel-heading">
        <h4>Pengaturan Harga Layanan</h4>
      </div>
      <div class="panel-body">
        <?php
        include '../koneksi.php';
        $data = mysqli_query($koneksi, "SELECT * FROM harga ORDER BY id ASC");
        if (isset($_GET['pesan']) && $_GET['pesan'] == "berhasil"): ?>
          <div class="alert alert-success">Harga berhasil diperbarui!</div>
        <?php endif; ?>

        <form method="post" action="harga_update.php">
          <?php while ($d = mysqli_fetch_array($data)): ?>
            <div class="form-group">
              <label><?= $d['layanan']; ?> (Rp)</label>
              <input type="number" class="form-control" name="harga[<?= $d['id']; ?>]" value="<?= $d['harga']; ?>" required>
            </div>
          <?php endwhile; ?>
          <br>
          <input type="submit" class="btn btn-primary-custom" value="Simpan Semua Perubahan">
        </form>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>