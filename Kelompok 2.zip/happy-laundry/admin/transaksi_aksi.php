<?php
include '../koneksi.php';

$pelanggan = $_POST['pelanggan'];
$berat = $_POST['berat'];
$tgl_selesai = $_POST['tgl_selesai'];
$tgl_hari_ini = date('Y-m-d');
$status = 0;
$layanan = $_POST['layanan'];


$harga_per_kg = $layanan == 'Cuci Saja' || $layanan == 'Setrika Saja' ? 4000 : ($layanan == 'Cuci & Setrika' ? 6000 : 10000);

$total_harga = $berat * $harga_per_kg;


mysqli_query($koneksi, "INSERT INTO transaksi SET
    transaksi_tgl = '$tgl_hari_ini',
    transaksi_pelanggan = '$pelanggan',
    transaksi_berat = '$berat',
    transaksi_tgl_selesai = '$tgl_selesai',
    transaksi_status = '$status',
    transaksi_layanan = '$layanan',
    transaksi_harga = '$total_harga'");

$transaksi_id = mysqli_insert_id($koneksi);


if (isset($_POST['pakaian'])) {
    foreach ($_POST['pakaian'] as $item) {
        $jenis = mysqli_real_escape_string($koneksi, $item['jenis']);
        $jumlah = (int)$item['jumlah'];
        mysqli_query($koneksi, "INSERT INTO pakaian (pakaian_transaksi, pakaian_jenis, pakaian_jumlah) VALUES ('$transaksi_id', '$jenis', '$jumlah')");
    }
}

header("location:transaksi.php?id=$transaksi_id");
