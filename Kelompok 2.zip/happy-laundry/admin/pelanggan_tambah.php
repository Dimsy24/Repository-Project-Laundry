<?php include 'header.php'; ?>
<style>
  .panel-custom {
    border-radius: 10px;
    box-shadow: 0 4px 12px rgb(9, 100, 161);
    animation: fadeInUp 0.7s ease-out forwards;
    opacity: 0;
    background-color: #f8f9fa;
    margin-top: 40px;
  }

  .panel-custom .panel-heading {
    background-color: #3399dd;
    color: white;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    padding: 15px 20px;
  }

  .panel-custom .panel-body {
    padding: 20px;
  }

  .btn-primary-custom {
    background-color: #3399dd;
    border-color: rgb(35, 167, 255);
    transition: 0.3s ease;
    box-shadow: 0 4px 0 #2c89c6;
    position: relative;
  }

  .btn-primary-custom:hover {
    background-color: #2c89c6;
    border-color: #2c89c6;
  }

  .btn-primary-custom:active {
    top: 2px;
    box-shadow: 0 1px 0 #1e6fa5;
  }

  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
</style>


<div class="container">
  <div class="col-md-5 col-md-offset-3">
    <div class="panel panel-custom">
      <div class="panel-heading">
        <h4>Tambah Pelanggan Baru</h4>
      </div>
      <div class="panel-body">
        <form method="post" action="pelanggan_aksi.php">
          <div class="form-group">
            <label>Nama</label>
            <input type="text" class="form-control" name="nama" placeholder="Masukkan nama.." required>
          </div>
          <div class="form-group">
            <label>HP</label>
            <input type="number" class="form-control" name="hp" placeholder="Masukkan No.HP.." required>
          </div>
          <div class="form-group">
            <label>Alamat</label>
            <input type="text" class="form-control" name="alamat" placeholder="Masukkan Alamat.." required>
          </div>
          <br>
          <input type="submit" class="btn btn-primary-custom btn-block" value="Simpan">
        </form>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>
