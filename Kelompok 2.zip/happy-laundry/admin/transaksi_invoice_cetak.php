<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak pesanan pelanggan</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.css" type="text/css">
    <script type="text/javascript" src="../assets/js/jquery.js"></script>
    <script type="text/javascript" src="../assets/js/bootstrap.js"></script>
</head>

<body>
    <?php
    session_start();
    if ($_SESSION['status'] != "login") {
        header("location:../index.php?pesan=belum_login");
    }

    include '../koneksi.php';
    ?>

    <div class="container">
        <div class="col-md-10 col-md-offset-1">
            <?php
            $id = $_GET['id'];
            $transaksi = mysqli_query($koneksi, "SELECT * FROM transaksi, pelanggan WHERE transaksi_id='$id' AND transaksi_pelanggan=pelanggan_id");
            $t = mysqli_fetch_array($transaksi);
            ?>
            <center>
                <h2>HAPPY LAUNDRY</h2>
            </center>
            <h3>INVOICE-<?php echo $t['transaksi_id']; ?></h3>
            <br>
            <table class="table">
                <tr>
                    <th width="20%">No. Invoice</th>
                    <th>:</th>
                    <td>INVOICE-<?php echo $t['transaksi_id']; ?></td>
                </tr>
                <tr>
                    <th width="20%">Tgl. Laundry</th>
                    <th>:</th>
                    <td><?php echo $t['transaksi_tgl']; ?></td>
                </tr>
                <tr>
                    <th>Nama Pelanggan</th>
                    <th>:</th>
                    <td><?php echo $t['pelanggan_nama']; ?></td>
                </tr>
                <tr>
                    <th>No. HP</th>
                    <th>:</th>
                    <td><?php echo $t['pelanggan_hp']; ?></td>
                </tr>
                <tr>
                    <th>Alamat</th>
                    <th>:</th>
                    <td><?php echo $t['pelanggan_alamat']; ?></td>
                </tr>
                <tr>
                    <th>Layanan</th>
                    <th>:</th>
                    <td><?php echo $t['transaksi_layanan']; ?></td>
                </tr>
                <tr>
                    <th>Berat Cucian (Kg)</th>
                    <th>:</th>
                    <td><?php echo $t['transaksi_berat']; ?> Kg</td>
                </tr>
                <tr>
                    <th>Tgl. Selesai</th>
                    <th>:</th>
                    <td><?php echo $t['transaksi_tgl_selesai']; ?></td>
                </tr>
                <tr>
                    <th>Harga</th>
                    <th>:</th>
                    <td><?php echo "Rp. " . number_format($t['transaksi_harga']) . " ,-"; ?></td>
                </tr>
            </table>
            <br>
            <h4 class="text-center">Daftar Cucian</h4>
            <table class="table table-bordered table-striped">
                <tr>
                    <th>Jenis Pakaian</th>
                    <th width="20%">Jumlah</th>
                </tr>
                <?php
                
                $pakaian_query = mysqli_query($koneksi, "SELECT * FROM pakaian WHERE pakaian_transaksi='$id'");
                $total_pakaian = 0;
                if (mysqli_num_rows($pakaian_query) > 0) {
                    $total_pakaian = 0;
                    while ($p = mysqli_fetch_array($pakaian_query)) {
                        echo "<tr>
                <td>" . htmlspecialchars($p['pakaian_jenis']) . "</td>
                <td>" . $p['pakaian_jumlah'] . "</td>
            </tr>";
                        $total_pakaian += $p['pakaian_jumlah'];
                    }

                    
                    echo "<tr>
                <td style='font-weight: bold;'>Total</td>
                <td style='font-weight: bold;'>$total_pakaian</td>
            </tr>";
                }

                ?>
            

            </table>
            <br>
            <p>
                <center><i>JAGONYA BERSIH DAN WANGI</i></center>
            </p>
        </div>
    </div>
    <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>

</html>