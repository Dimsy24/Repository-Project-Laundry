<?php
session_start();
include '../koneksi.php';

if (isset($_POST['harga']) && is_array($_POST['harga'])) {
    foreach ($_POST['harga'] as $id => $nilai) {
        $id = intval($id);
        $nilai = intval($nilai);
        mysqli_query($koneksi, "UPDATE harga SET harga = '$nilai' WHERE id = '$id'");
    }
}

header("location:harga.php?pesan=berhasil");
