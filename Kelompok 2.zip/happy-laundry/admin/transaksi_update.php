<?php
include '../koneksi.php';

$id = $_POST['id'];
$pelanggan = $_POST['pelanggan'];
$berat = $_POST['berat'];
$tgl_selesai = $_POST['tgl_selesai'];
$status = $_POST['status'];
$layanan = $_POST['layanan'];

// Ambil harga per kilo dari tabel harga
$harga_per_kilo_query = mysqli_query($koneksi, "SELECT harga FROM harga WHERE layanan='$layanan'");
$harga_per_kilo_data = mysqli_fetch_assoc($harga_per_kilo_query);
$harga_per_kilo = $harga_per_kilo_data['harga'];

// Hitung total
$total_harga = $harga_per_kilo * $berat;

// Update transaksi utama
mysqli_query($koneksi, "UPDATE transaksi SET 
  transaksi_pelanggan='$pelanggan', 
  transaksi_layanan='$layanan',
  transaksi_harga='$total_harga', 
  transaksi_berat='$berat', 
  transaksi_tgl_selesai='$tgl_selesai', 
  transaksi_status='$status' 
  WHERE transaksi_id='$id'");

// Hapus pakaian lama
mysqli_query($koneksi, "DELETE FROM pakaian WHERE pakaian_transaksi='$id'");

// Tambahkan pakaian baru dari form
if (isset($_POST['pakaian'])) {
  foreach ($_POST['pakaian'] as $item) {
    $jenis = mysqli_real_escape_string($koneksi, $item['jenis']);
    $jumlah = (int)$item['jumlah'];

    if ($jenis !== "" && $jumlah > 0) {
      mysqli_query($koneksi, "INSERT INTO pakaian (pakaian_transaksi, pakaian_jenis, pakaian_jumlah) 
      VALUES ('$id', '$jenis', '$jumlah')");
    }
  }
}

header("Location: transaksi.php");
