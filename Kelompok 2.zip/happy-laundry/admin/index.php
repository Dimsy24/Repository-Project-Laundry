<?php include 'header.php'; ?>
<?php include '../koneksi.php'; ?>

<style>
  .dashboard-box {
    border-radius: 12px;
    padding: 25px 15px;
    margin-bottom: 20px;
    color: white;
    font-weight: bold;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    text-align: center;
  }

  .dashboard-box:hover {
    transform: translateY(-5px);
  }

  .dashboard-primary {
    background-color: #1e90ff;
  }

  .dashboard-warning {
    background-color: #ffc107;
    color: #000;
  }

  .dashboard-info {
    background-color: #17a2b8;
  }

  .dashboard-success {
    background-color: #28a745;
  }

  .dashboard-value {
    font-size: 40px;
    margin-bottom: 10px;
  }

  .dashboard-label {
    font-size: 16px;
    font-weight: 600;
  }

  .table-title-colored {
    background-color: #3399dd;
    color: white;
    padding: 12px 20px;
    font-size: 18px;
    font-weight: bold;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
  }

  .thead-pink {
    background-color: #3399dd;
    color: white;
  }

  .row-proses {
    background-color: #fff3cd !important;
  }

  .row-dicuci {
    background-color: #d1ecf1 !important;
  }

  .row-selesai {
    background-color: #d4edda !important;
  }
</style>

<div class="container">
  <div class="row">
    <div class="col-md-3">
      <div class="dashboard-box dashboard-primary"></div>
    </div>
    <div class="col-md-3">
      <div class="dashboard-box dashboard-warning"></div>
    </div>
    <div class="col-md-3">
      <div class="dashboard-box dashboard-info"></div>
    </div>
    <div class="col-md-3">
      <div class="dashboard-box dashboard-success"></div>
    </div>
  </div>

  <script>
    $(document).ready(function() {
      $(".dashboard-primary").html(`
        <div class="dashboard-value">
          <i class="glyphicon glyphicon-user"></i><br>
          <?= mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM pelanggan")); ?>
        </div>
        <div class="dashboard-label">Jumlah Pelanggan</div>
      `);
      $(".dashboard-warning").html(`
        <div class="dashboard-value">
          <i class="glyphicon glyphicon-retweet"></i><br>
          <?= mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM transaksi WHERE transaksi_status='0'")); ?>
        </div>
        <div class="dashboard-label">Jumlah Cucian di proses</div>
      `);
      $(".dashboard-info").html(`
        <div class="dashboard-value">
          <i class="glyphicon glyphicon-info-sign"></i><br>
          <?= mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM transaksi WHERE transaksi_status='1'")); ?>
        </div>
        <div class="dashboard-label">Proses Pencucian</div>
      `);
      $(".dashboard-success").html(`
        <div class="dashboard-value">
          <i class="glyphicon glyphicon-ok-circle"></i><br>
          <?= mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM transaksi WHERE transaksi_status='2'")); ?>
        </div>
        <div class="dashboard-label">Jumlah cucian selesai</div>
      `);
    });
  </script>

  <div class="panel">
    <div class="panel-heading table-title-colored">
      <h4>Riwayat Transaksi Terakhir</h4>
    </div>
    <div class="panel-body">
      <table class="table table-bordered table-striped">
        <thead class="thead-pink">
          <tr>
            <th width="1%">No</th>
            <th>Invoice</th>
            <th>Tanggal</th>
            <th>Pelanggan</th>
            <th>Berat (Kg)</th>
            <th>Tgl. Selesai</th>
            <th>Harga</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $data = mysqli_query($koneksi, "SELECT * FROM pelanggan,transaksi WHERE transaksi_pelanggan=pelanggan_id ORDER BY transaksi_id DESC LIMIT 7");
          $no = 1;
          while ($d = mysqli_fetch_array($data)) {
            $status_class = '';
            if ($d['transaksi_status'] == "0") {
              $status_class = 'row-proses';
              $label = "<span class='label label-warning'>PROSES</span>";
            } else if ($d['transaksi_status'] == "1") {
              $status_class = 'row-dicuci';
              $label = "<span class='label label-info'>DICUCI</span>";
            } else if ($d['transaksi_status'] == "2") {
              $status_class = 'row-selesai';
              $label = "<span class='label label-success'>SELESAI</span>";
            }
          ?>
            <tr class="<?= $status_class; ?>">
              <td><?= $no++; ?></td>
              <td>INVOICE-<?= $d['transaksi_id']; ?></td>
              <td><?= $d['transaksi_tgl']; ?></td>
              <td><?= $d['pelanggan_nama']; ?></td>
              <td><?= $d['transaksi_berat']; ?></td>
              <td><?= $d['transaksi_tgl_selesai']; ?></td>
              <td><?= "Rp. " . number_format($d['transaksi_harga']) . " ,-"; ?></td>
              <td><?= $label; ?></td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>