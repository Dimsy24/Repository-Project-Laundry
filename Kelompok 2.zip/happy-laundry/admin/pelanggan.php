<?php include 'header.php'; ?>
<style>
  .table-title-colored {
    background-color: #3399dd;
    color: white;
    padding: 12px 20px;
    font-size: 18px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
  }

  .thead-pink {
    background-color: #3399dd;
    color: white;
  }

  .btn-custom-blue {
    background-color: #00bcd4;
    border: none;
    color: white;
    font-weight: bold;
  }

  .btn-custom-blue:hover {
    background-color: #00acc1;
    transform: scale(1.05);
  }

  @keyframes fadeInUp {
    0% {
      opacity: 0;
      transform: translateY(20px);
    }

    100% {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .animate-fade-in {
    opacity: 0;
    animation: fadeInUp 0.2s ease-out forwards;
  }
</style>

<div class="container">
  <div class="panel animate-fade-in animate-delay-1">
    <div class="panel-heading table-title-colored">
      <h4>Data Pelanggan</h4>
    </div>
    <div class="panel-body">
      <a href="pelanggan_tambah.php" class="btn btn-sm btn-custom-blue pull-right animate-fade-in animate-delay-2"
        style="margin-bottom: 15px;">Tambah</a>
      <br><br>
      <table class="table table-bordered table-striped animate-fade-in animate-delay-3">
        <thead class="thead-pink">
          <tr>
            <th width="1%">No</th>
            <th>Nama</th>
            <th>HP</th>
            <th>Alamat</th>
            <th width="15%">OPSI</th>
          </tr>
        </thead>
        <tbody>
          <?php
          include '../koneksi.php';
          $data = mysqli_query($koneksi, "SELECT * FROM pelanggan");
          $no = 1;
          $delay = 0.1;
          while ($d = mysqli_fetch_array($data)) {
          ?>
            <tr class="fadeInRow" style="animation-delay: <?= $delay ?>s;">
              <td><?= $no++; ?></td>
              <td><?= $d['pelanggan_nama']; ?></td>
              <td><?= $d['pelanggan_hp']; ?></td>
              <td><?= $d['pelanggan_alamat']; ?></td>
              <td>
                <a href="pelanggan_edit.php?id=<?= $d['pelanggan_id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                <button class="btn btn-sm btn-danger btn-hapus" data-id="<?= $d['pelanggan_id']; ?>">Hapus</button>
              </td>
            </tr>
          <?php
            $delay += 0.05;
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<script>
  document.querySelectorAll('.btn-hapus').forEach(function(button) {
    button.addEventListener('click', function(e) {
      const id = this.getAttribute('data-id');
      const konfirmasi = confirm('Apakah Anda yakin ingin menghapus data ini?');
      if (konfirmasi) {
        
        window.location.href = 'pelanggan_hapus.php?id=' + id;
      }
    });
  });
</script>
<?php include 'footer.php'; ?>