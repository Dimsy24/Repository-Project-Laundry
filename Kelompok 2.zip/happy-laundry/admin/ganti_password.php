<?php include 'header.php'; ?>
<style>
  .panel-custom {
    border-radius: 10px;
    background-color: #fefefe;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    animation: fadeInUp 0.7s ease-out forwards;
    opacity: 0;
    margin-top: 40px;
  }

  .panel-custom .panel-heading {
    background-color: #3399dd;
    color: white;
    padding: 15px 25px;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
  }

  .panel-custom .panel-body {
    padding: 25px;
  }

  .btn-primary-custom {
    background-color: #3399dd;
    border-color: #2c89c6;
    color: white;
    width: 100%;
    transition: all 0.3s ease;
  }

  .btn-primary-custom:hover {
    background-color: #2c89c6;
  }

  @keyframes fadeInUp {
    from { opacity: 0; transform: translateY(30px); }
    to { opacity: 1; transform: translateY(0); }
  }

  .alert-success {
    animation: fadeInUp 0.6s ease;
  }
</style>

<div class="container">
  <div class="col-md-5 col-md-offset-3">
    <?php if (isset($_GET['pesan']) && $_GET['pesan'] == "oke"): ?>
      <div class="alert alert-success">
        Password telah berhasil diganti!
      </div>
    <?php endif; ?>

    <div class="panel panel-custom">
      <div class="panel-heading">
        <h4>Ganti Password</h4>
      </div>
      <div class="panel-body">
        <form method="post" action="ganti_password_aksi.php">
          <div class="form-group">
            <label>Masukkan Password Baru</label>
            <input type="password" class="form-control" name="password_baru" placeholder="Masukkan Password Baru Anda.." required>
          </div>
          <br>
          <input type="submit" class="btn btn-primary-custom" value="Ganti Password">
        </form>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>
