<?php
include '../koneksi.php';

$query = "SELECT pelanggan_id, pelanggan_nama FROM pelanggan";
$result = mysqli_query($koneksi, $query);

$pelanggan = array();
while ($row = mysqli_fetch_assoc($result)) {
    $pelanggan[] = array(
        'id' => $row['pelanggan_id'],
        'label' => $row['pelanggan_nama'], 
        'value' => $row['pelanggan_nama']  
    );
}

echo json_encode($pelanggan);
