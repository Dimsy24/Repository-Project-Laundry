<?php include 'header.php'; ?>

<style>
  .panel-custom {
    border-radius: 10px;
    box-shadow: 0 4px 12px rgba(9, 100, 161, 0.3);
    animation: fadeInUp 0.3s ease-out forwards;
    opacity: 0;
    background-color: #f8f9fa;
    margin-top: 40px;
  }

  .panel-custom .panel-heading {
    background-color: #3399dd;
    color: white;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    padding: 15px 20px;
  }

  .panel-custom .panel-body {
    padding: 20px;
  }

  .btn-primary-custom {
    background-color: #3399dd;
    border-color: #2c89c6;
    color: white;
    transition: 0.3s ease;
    box-shadow: 0 4px 0 #2c89c6;
    position: relative;
    animation: fadeInUp 0.3s ease-out forwards;
    opacity: 0;
  }

  .btn-primary-custom:hover {
    background-color: #2c89c6;
    border-color: #2c89c6;
  }

  .btn-primary-custom:active {
    top: 2px;
    box-shadow: 0 1px 0 #1e6fa5;
  }

  .thead-colored {
    background-color: #3399dd;
    color: white;
  }
</style>

<div class="container">
  <div class="panel panel-custom">
    <div class="panel-heading">
      <h4>Data Transaksi Laundry</h4>
    </div>
    <div class="panel-body">
      <a href="transaksi_tambah.php" class="btn btn-sm btn-primary-custom pull-right">Transaksi Baru</a>
      <br><br>
      <table class="table table-bordered table-striped">
        <thead class="thead-colored">
          <tr>
            <th width="1%">No</th>
            <th>Invoice</th>
            <th>Tanggal</th>
            <th>Pelanggan</th>
            <th>Layanan</th>
            <th>Berat (Kg)</th>
            <th>Tgl. Selesai</th>
            <th>Harga</th>
            <th>Status</th>
            <th width="20%">OPSI</th>
          </tr>
        </thead>
        <tbody>
          <?php
          include '../koneksi.php';
          $data = mysqli_query($koneksi, "
          SELECT transaksi.*, pelanggan.pelanggan_nama 
          FROM transaksi 
          JOIN pelanggan ON transaksi_pelanggan = pelanggan_id 
          ORDER BY transaksi_id DESC
        ");
          $no = 1;
          $delay = 0.2;
          while ($d = mysqli_fetch_array($data)) {
            $delay += 0.03;
          ?>
            <tr class="fadeInRow" style="animation-delay: <?= $delay; ?>s;">
              <td><?= $no++; ?></td>
              <td>INVOICE-<?= $d['transaksi_id']; ?></td>
              <td><?= $d['transaksi_tgl']; ?></td>
              <td><?= $d['pelanggan_nama']; ?></td>
              <td><?= $d['transaksi_layanan']; ?></td>
              <td><?= $d['transaksi_berat']; ?></td>
              <td><?= $d['transaksi_tgl_selesai']; ?></td>
              <td><?= "Rp. " . number_format($d['transaksi_harga']) . " ,-"; ?></td>
              <td>
                <?php
                if ($d['transaksi_status'] == "0") {
                  echo "<div class='label label-warning'>PROSES</div>";
                } else if ($d['transaksi_status'] == "1") {
                  echo "<div class='label label-info'>DICUCI</div>";
                } else if ($d['transaksi_status'] == "2") {
                  echo "<div class='label label-success'>SELESAI</div>";
                }
                ?>
              </td>
              <td>
                <a href="transaksi_invoice.php?id=<?= $d['transaksi_id']; ?>" class="btn btn-sm btn-warning">Cetak</a>
                <a href="transaksi_edit.php?id=<?= $d['transaksi_id']; ?>" class="btn btn-sm btn-info">Edit</a>
                <button class="btn btn-sm btn-danger btn-hapus" data-id="<?= $d['transaksi_id']; ?>">Hapus</button>
              </td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<script>
  document.querySelectorAll('.btn-hapus').forEach(function(button) {
    button.addEventListener('click', function(e) {
      const id = this.getAttribute('data-id');
      const konfirmasi = confirm('Apakah Anda yakin ingin menghapus data ini?');
      if (konfirmasi) {
        
        window.location.href = 'transaksi_hapus.php?id=' + id;
      }
    });
  });
</script>


<?php include 'footer.php'; ?>