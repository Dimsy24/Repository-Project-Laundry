<?php include 'header.php'; ?>
<?php include '../koneksi.php'; ?>

<style>
  .panel-custom {
    border-radius: 10px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    background-color: #fefefe;
    animation: fadeInUp 0.7s ease-out forwards;
    opacity: 0;
    margin-top: 50px;
  }

  .panel-custom .panel-heading {
    background-color: #3399dd;
    color: white;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    padding: 15px 25px;
  }

  .panel-custom .panel-body {
    padding: 25px;
  }

  .btn-primary-custom {
    background-color: #3399dd;
    border-color: #2c89c6;
    color: white;
    transition: 0.3s ease;
    box-shadow: 0 4px 0 #2c89c6;
  }

  .btn-primary-custom:hover {
    background-color: #2c89c6;
    border-color: #2c89c6;
  }

  .btn-info-custom {
    background-color: #17a2b8;
    border-color: #138496;
    color: white;
  }

  .btn-info-custom:hover {
    background-color: #138496;
  }

  .form-section {
    margin-bottom: 25px;
  }

  table.table-bordered th {
    background-color: #3399dd;
    color: white;
    text-align: center;
  }

  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(30px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
</style>

<div class="container">
  <div class="col-md-8 col-md-offset-2">
    <div class="panel panel-custom">
      <div class="panel-heading">
        <h4>Transaksi Laundry Baru</h4>
      </div>
      <div class="panel-body">
        <div class="clearfix"></div>
        <br>

        <form action="transaksi_aksi.php" method="post">
          <div class="form-section">
            <label>Pelanggan</label>
            <input type="text" id="pelanggan" class="form-control" placeholder="Masukkan nama pelanggan" required>
            <input type="hidden" name="pelanggan" id="pelanggan_id">
          </div>
          <div class="form-section">
            <label>Layanan</label>
            <select name="layanan" class="form-control" required>
              <option value="">- Pilih Layanan -</option>
              <option value="Cuci Saja">Cuci Saja - Rp4.000</option>
              <option value="Setrika Saja">Setrika Saja - Rp4.000</option>
              <option value="Cuci & Setrika">Cuci & Setrika - Rp6.000</option>
              <option value="Express">Express - Rp10.000</option>
            </select>
          </div>
          <div class="form-section">
            <label>Berat (Kg)</label>
            <input type="number" class="form-control" name="berat" placeholder="Masukkan berat cucian" required>
          </div>

          <div class="form-section">
            <label>Tanggal Selesai</label>
            <input type="date" class="form-control" name="tgl_selesai" required>
          </div>
          <div class="form-section">
            <label>Daftar Cucian</label>
            <table class="table table-bordered" id="daftarCucian">
              <thead>
                <tr>
                  <th>Jenis Pakaian</th>
                  <th>Jumlah</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><input type="text" class="form-control" name="pakaian[0][jenis]" placeholder="Jenis pakaian" required></td>
                  <td><input type="number" class="form-control jumlah-pakaian" name="pakaian[0][jumlah]" placeholder="Jumlah" required></td>
                  <td><button type="button" class="btn btn-danger" onclick="hapusBaris(this)">Hapus</button></td>
                </tr>
              </tbody>
            </table>
            <button type="button" class="btn btn-primary" id="btn-tambah">Tambah Pakaian</button>
          </div>

          <div class="form-section">
            <label>Total Pakaian</label>
            <input type="number" class="form-control" id="totalPakaian" value="0" readonly>
          </div>

          <input type="submit" class="btn btn-primary-custom btn-block" value="Simpan">
        </form>
      </div>
    </div>
  </div>
</div>

<script>
  $(document).ready(function() {

    $.ajax({
      url: 'get_pelanggan.php',
      method: 'GET',
      dataType: 'json',
      success: function(data) {

        $("#pelanggan").autocomplete({
          source: data,
          select: function(event, ui) {

            $("#pelanggan_id").val(ui.item.id);
          }
        });
      }
    });

    let counter = 1;

    document.getElementById('btn-tambah').addEventListener('click', function() {
      const tableBody = document.querySelector('#daftarCucian tbody');
      const newRow = document.createElement('tr');
      newRow.innerHTML = `
        <td><input type="text" class="form-control" name="pakaian[${counter}][jenis]" placeholder="Jenis pakaian" required></td>
        <td><input type="number" class="form-control jumlah-pakaian" name="pakaian[${counter}][jumlah]" placeholder="Jumlah" required></td>
        <td><button type="button" class="btn btn-danger" onclick="hapusBaris(this)">Hapus</button></td>
    `;
      tableBody.appendChild(newRow);
      counter++;
      updateTotalPakaian();
    });

    window.hapusBaris = function(button) {
      button.closest('tr').remove();
      updateTotalPakaian();
    }

    function updateTotalPakaian() {
      const inputs = document.querySelectorAll('.jumlah-pakaian');
      let total = 0;
      inputs.forEach(input => {
        total += parseInt(input.value) || 0;
      });
      document.getElementById('totalPakaian').value = total;
    }

    document.querySelector('#daftarCucian').addEventListener('input', function(e) {
      if (e.target.classList.contains('jumlah-pakaian')) {
        updateTotalPakaian();
      }
    });
  });
</script>

<?php include 'footer.php'; ?>