<?php
// Sertakan file navbar.php untuk tampilan navigasi
include 'navbar.php';

// Mulai session di awal
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Sertakan file koneksi database
// Pastikan path ini benar sesuai lokasi file koneksi.php Anda
include 'koneksi.php';

// Variabel untuk pesan feedback
$pesan_feedback = "";
$feedback_type = "";

// Cek apakah pengguna sudah login, jika belum, redirect ke halaman login
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit();
}

// Ambil id_user dari session
$id_user_login = $_SESSION['id_user'];
$nama_user_login = '';
$riwayat_pesanan = []; // Array untuk menyimpan data riwayat pesanan

// Ambil nama lengkap pengguna dari database berdasarkan id_user
// Menggunakan prepared statement untuk keamanan
$sql_get_nama = "SELECT nama FROM user WHERE id_user = ?";
$stmt_get_nama = mysqli_prepare($koneksi, $sql_get_nama);

if ($stmt_get_nama) {
    mysqli_stmt_bind_param($stmt_get_nama, "i", $id_user_login);
    mysqli_stmt_execute($stmt_get_nama);
    $result_get_nama = mysqli_stmt_get_result($stmt_get_nama);
    if ($row_nama = mysqli_fetch_assoc($result_get_nama)) {
        $nama_user_login = $row_nama['nama'];
    } else {
        $pesan_feedback = "Data pengguna tidak ditemukan.";
        $feedback_type = "danger";
    }
    mysqli_stmt_close($stmt_get_nama);
} else {
    $pesan_feedback = "Gagal mengambil data pengguna: " . mysqli_error($koneksi);
    $feedback_type = "danger";
}

// Query untuk mengambil riwayat pesanan user yang sedang login
// Mengambil id_pesanan, nama_barang, berat, dan harga dari tabel 'pesanan'
// Filter berdasarkan id_user yang sedang login
$sql_riwayat = "SELECT id_pesanan, nama_barang, berat, harga 
                FROM pesanan 
                WHERE id_user = ?";
$stmt_riwayat = mysqli_prepare($koneksi, $sql_riwayat);

if ($stmt_riwayat) {
    mysqli_stmt_bind_param($stmt_riwayat, "i", $id_user_login);
    mysqli_stmt_execute($stmt_riwayat);
    $result_riwayat = mysqli_stmt_get_result($stmt_riwayat);

    // Ambil semua baris hasil query
    while ($row = mysqli_fetch_assoc($result_riwayat)) {
        $riwayat_pesanan[] = $row;
    }
    mysqli_stmt_close($stmt_riwayat);
} else {
    $pesan_feedback = "Gagal mengambil riwayat pesanan: " . mysqli_error($koneksi);
    $feedback_type = "danger";
}

// Tutup koneksi database
mysqli_close($koneksi);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pesanan Laundry - Toko Ungu</title>
    <!-- Menggunakan Bootstrap dari folder lokal -->
    <!-- Pastikan path ini benar sesuai lokasi file bootstrap.min.css Anda -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0e6f7; /* Ungu muda sebagai background utama halaman */
            color: #333;
        }
        .container-riwayat {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(106, 27, 154, 0.2); /* Bayangan dengan hint ungu */
            margin-top: 20px;
            max-width: 800px; /* Lebar yang lebih luas untuk tabel */
            margin-left: auto;
            margin-right: auto;
        }
        .container-riwayat h2 {
            color: #6a1b9a; /* Judul form dengan warna ungu gelap */
            text-align: center;
            margin-bottom: 25px;
        }
        .table-custom {
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden; /* Untuk memastikan border-radius bekerja pada tabel */
        }
        .table-custom thead {
            background-color: #8e24aa; /* Header tabel ungu sedang */
            color: #fff;
        }
        .table-custom th, .table-custom td {
            vertical-align: middle;
            padding: 12px;
        }
        .table-custom tbody tr:nth-child(even) {
            background-color: #f8f0fc; /* Warna latar belakang selang-seling */
        }
        .alert {
            margin-top: 15px;
        }
    </style>
</head>
<body>

    <?php 
    // Sertakan navbar Anda
    // Pastikan path ini benar sesuai lokasi file navbar.php Anda
    ?>

    <div class="container">
        <div class="container-riwayat">
            <h2>Riwayat Pesanan Laundry Anda</h2>
            <p class="text-center">Selamat datang, <strong><?php echo htmlspecialchars($nama_user_login); ?></strong>!</p>

            <?php if (!empty($pesan_feedback)): ?>
                <div class="alert alert-<?php echo $feedback_type; ?> alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($pesan_feedback); // Selalu escape output HTML ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if (!empty($riwayat_pesanan)): ?>
                <div class="table-responsive">
                    <table class="table table-hover table-custom">
                        <thead>
                            <tr>
                                <th>ID Pesanan</th>
                                <th>Jenis Laundry</th>
                                <th>Berat (kg)</th>
                                <th>Total Harga</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($riwayat_pesanan as $pesanan): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($pesanan['id_pesanan']); ?></td>
                                    <td><?php echo htmlspecialchars($pesanan['nama_barang']); ?></td>
                                    <td><?php echo htmlspecialchars(number_format($pesanan['berat'], 2, ',', '.')); ?></td>
                                    <td>Rp <?php echo htmlspecialchars(number_format($pesanan['harga'], 0, ',', '.')); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info text-center" role="alert">
                    Anda belum memiliki riwayat pesanan laundry. Silakan <a href="pesan.php" class="alert-link">buat pesanan baru</a>.
                </div>
            <?php endif; ?>
        </div>
    </div> <br><br><br><br><br><br><br><br><br><br><br>
        <?php include 'footer.php' ?>


    <!-- Menggunakan Bootstrap JS dari folder lokal -->
    <!-- Pastikan path ini benar sesuai lokasi file bootstrap.bundle.min.js Anda -->
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
