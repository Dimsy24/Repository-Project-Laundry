<?php
// Informasi koneksi database
$host = "localhost";     // Nama host database
$user = "root";          // Username MySQL (default: root)
$password = "";          // Password MySQL (kosong jika default XAMPP)
$database = "laundry";   // Nama database

// Membuat koneksi
$koneksi = new mysqli($host, $user, $password, $database);

// Cek koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
} else {
    //echo "Koneksi ke database 'laundry' berhasil!";
}
?>
