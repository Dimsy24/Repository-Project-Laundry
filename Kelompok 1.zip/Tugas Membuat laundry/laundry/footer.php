<?php
// footer.php
?>
<footer class="footer">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> Laundry Harapan. All rights reserved. Dibuat oleh Faiz Gunawan Yoandra(232350021),Roy Mahendra(232350007),Astri Dwi Yanti(232350010) </p>
    </div>
</footer>

<style>
    /* Styling untuk footer */
    .footer {
        background-color:rgb(38, 38, 38); /* Ungu gelap untuk footer */
        color: #fff;
        padding: 20px 0;
        text-align: center;
        margin-top: auto; /* Mendorong footer ke bagian bawah halaman */
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
        box-shadow: 0 -4px 15px rgba(0, 0, 0, 0.1);
    }
    .footer p {
        margin: 0;
    }
</style>
