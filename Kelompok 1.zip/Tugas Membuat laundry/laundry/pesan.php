<?php
    include 'navbar.php'; 

// Mulai session di awal
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Sertakan file koneksi database
// Pastikan path ini benar sesuai lokasi file koneksi.php Anda
include 'koneksi.php'; 

// Variabel untuk pesan feedback
$pesan_feedback = "";
$feedback_type = ""; // "success" atau "danger"

// Cek apakah pengguna sudah login, jika belum, redirect ke halaman login
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit();
}

// Ambil id_user dari session
$id_user_login = $_SESSION['id_user'];
$nama_user_login = '';

// Ambil nama lengkap pengguna dari database berdasarkan id_user
// Menggunakan prepared statement untuk keamanan
$sql_get_nama = "SELECT nama FROM user WHERE id_user = ?";
$stmt_get_nama = mysqli_prepare($koneksi, $sql_get_nama);

if ($stmt_get_nama) {
    mysqli_stmt_bind_param($stmt_get_nama, "i", $id_user_login);
    mysqli_stmt_execute($stmt_get_nama);
    $result_get_nama = mysqli_stmt_get_result($stmt_get_nama);
    if ($row_nama = mysqli_fetch_assoc($result_get_nama)) {
        $nama_user_login = $row_nama['nama'];
    } else {
        // Handle jika user tidak ditemukan (seharusnya tidak terjadi jika session valid)
        $pesan_feedback = "Data pengguna tidak ditemukan.";
        $feedback_type = "danger";
    }
    mysqli_stmt_close($stmt_get_nama);
} else {
    // Handle error jika query prepare gagal
    $pesan_feedback = "Gagal mengambil data pengguna: " . mysqli_error($koneksi);
    $feedback_type = "danger";
}


// Proses form jika ada data yang dikirim (method POST) dan tombol submit_pesanan ditekan
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_pesanan'])) {
    // Ambil data dari form dan lakukan sanitasi dasar
    // Nama barang (sekarang menjadi "Laundry") tidak lagi diambil dari input form
    $nama_barang = "Laundry"; // Defaultkan nama barang menjadi "Laundry"
    $berat_str = $_POST['berat']; // Ambil sebagai string dulu

    // Validasi berat: harus numerik dan positif
    if (!is_numeric($berat_str) || floatval($berat_str) <= 0) {
        $pesan_feedback = "Berat laundry tidak valid. Harap masukkan angka positif.";
        $feedback_type = "danger";
    } else {
        $berat = floatval($berat_str); // Konversi ke float
        $harga_per_kg = 8000;
        $total_harga = $berat * $harga_per_kg;

        // Mulai transaksi untuk memastikan integritas data
        // Transaksi tidak lagi diperlukan karena hanya ada satu operasi INSERT
        // mysqli_begin_transaction($koneksi); // Tidak perlu lagi

        try {
            // 1. Insert data ke tabel 'pesanan' menggunakan prepared statement
            // Sekarang juga menyertakan id_user
            $sql_insert_pesanan = "INSERT INTO pesanan (nama_barang, berat, harga, id_user) VALUES (?, ?, ?, ?)";
            $stmt_insert = mysqli_prepare($koneksi, $sql_insert_pesanan);
            if ($stmt_insert) {
                mysqli_stmt_bind_param($stmt_insert, "sddi", $nama_barang, $berat, $total_harga, $id_user_login);
                mysqli_stmt_execute($stmt_insert);
                $id_pesanan_baru = mysqli_insert_id($koneksi); // Dapatkan ID pesanan yang baru saja di-insert
                mysqli_stmt_close($stmt_insert);

                if ($id_pesanan_baru > 0) {
                    // Jika insert berhasil
                    // Tidak ada lagi update ke tabel user karena id_pesanan tidak ada di sana
                    // mysqli_commit($koneksi); // Tidak perlu lagi commit transaksi
                    $pesan_feedback = "Pesanan laundry berhasil dibuat! Total pembayaran Anda adalah Rp " . number_format($total_harga, 0, ',', '.') . ". ID Pesanan Anda: " . $id_pesanan_baru;
                    $feedback_type = "success";
                } else {
                    throw new Exception("Gagal menyimpan pesanan, tidak ada ID pesanan baru yang dihasilkan.");
                }
            } else {
                throw new Exception("Gagal mempersiapkan statement simpan pesanan: " . mysqli_error($koneksi));
            }
        } catch (Exception $e) {
            // mysqli_rollback($koneksi); // Tidak perlu lagi rollback transaksi
            $pesan_feedback = "Terjadi kesalahan: " . $e->getMessage();
            $feedback_type = "danger";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pemesanan Laundry - Toko Ungu</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0e6f7; /* Ungu muda sebagai background utama halaman */
            color: #333;
            /* Untuk mengakomodasi navbar fixed-top jika ada dari navbar.php */
        }
        /* Pastikan style navbar di navbar.php tidak bertentangan atau sesuaikan di sini jika perlu */
        .container-form {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(106, 27, 154, 0.2); /* Bayangan dengan hint ungu */
            margin-top: 20px;
            max-width: 600px; /* Batasi lebar form */
            margin-left: auto;
            margin-right: auto;
        }
        .container-form h2 {
            color: #6a1b9a; /* Judul form dengan warna ungu gelap */
            text-align: center;
            margin-bottom: 25px;
        }
        .form-label {
            color: #4a148c; /* Label form dengan warna ungu tua */
            font-weight: bold;
        }
        .form-control:focus {
            border-color: #ab47bc; /* Border ungu muda saat focus */
            box-shadow: 0 0 0 0.25rem rgba(171, 71, 188, 0.25);
        }
        .form-control[readonly] {
            background-color: #e9ecef; /* Warna background untuk field readonly */
            cursor: not-allowed;
        }
        .btn-pesan {
            background-color: #8e24aa; /* Tombol dengan warna ungu sedang */
            border-color: #8e24aa;
            color: #fff;
            width: 100%;
        }
        .btn-pesan:hover {
            background-color: #ab47bc;
            border-color: #ab47bc;
        }
        .modal-header-custom {
            background-color: #6a1b9a;
            color: #fff;
        }
        .modal-header-custom .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%); /* Agar tombol close terlihat di background gelap */
        }
        .modal-body p {
            font-size: 1.1rem;
        }
        .modal-body strong {
            color: #4a148c;
        }
        .btn-bayar {
            background-color: #5e35b1; /* Ungu lebih tua untuk tombol bayar */
            border-color: #5e35b1;
            color: #fff;
        }
        .btn-bayar:hover {
            background-color: #4527a0;
            border-color: #4527a0;
        }
        .alert {
            margin-top: 15px;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="container-form">
            <h2>Form Pemesanan Laundry</h2>

            <?php if (!empty($pesan_feedback)): ?>
                <div class="alert alert-<?php echo $feedback_type; ?> alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($pesan_feedback); // Selalu escape output HTML ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <form id="formPemesanan" action="pesan.php" method="POST">
                <div class="mb-3">
                    <label for="nama_user" class="form-label">Nama Pemesan</label>
                    <input type="text" class="form-control" id="nama_user" name="nama_user" value="<?php echo htmlspecialchars($nama_user_login); ?>" readonly>
                </div>
                <div class="mb-3">
                    <label for="berat" class="form-label">Berat Laundry (kg)</label>
                    <input type="number" class="form-control" id="berat" name="berat" step="0.01" min="0.01" required>
                    <div class="form-text">Harga per kg: Rp 8.000. Contoh: 0.5 untuk 500 gram, 1.25 untuk 1.25 kg.</div>
                </div>
                
                <button type="button" class="btn btn-pesan" id="btnKonfirmasiPesan">Pesan Sekarang</button>

                <button type="submit" name="submit_pesanan" id="realSubmitButton" style="display: none;">Submit</button>
            </form>
        </div>
    </div>

    <div class="modal fade" id="konfirmasiModal" tabindex="-1" aria-labelledby="konfirmasiModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header modal-header-custom">
                    <h5 class="modal-title" id="konfirmasiModalLabel">Konfirmasi Pembayaran Laundry</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Anda akan memesan laundry dengan berat <strong id="modalBeratBarang"></strong> kg.</p>
                    <p>Total biaya yang harus dibayar adalah: <strong>Rp <span id="modalTotalHarga"></span></strong></p>
                    <p>Apakah Anda yakin ingin melanjutkan pembayaran?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-bayar" id="btnLanjutkanPembayaran">Ya, Bayar & Pesan</button>
                </div>
            </div>
        </div>
    </div>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const btnKonfirmasiPesan = document.getElementById('btnKonfirmasiPesan');
            // Inisialisasi modal hanya jika elemennya ada
            const konfirmasiModalElement = document.getElementById('konfirmasiModal');
            let konfirmasiModalInstance = null;
            if (konfirmasiModalElement) {
                   konfirmasiModalInstance = new bootstrap.Modal(konfirmasiModalElement);
            }
            
            const beratInput = document.getElementById('berat');
            
            const modalBeratBarang = document.getElementById('modalBeratBarang');
            const modalTotalHarga = document.getElementById('modalTotalHarga');
            
            const realSubmitButton = document.getElementById('realSubmitButton');

            const hargaPerKg = 8000;

            if (btnKonfirmasiPesan) {
                btnKonfirmasiPesan.addEventListener('click', function () {
                    // Pastikan semua elemen yang dibutuhkan ada sebelum diakses
                    if (!beratInput || !modalBeratBarang || !modalTotalHarga || !konfirmasiModalInstance) {
                        console.error("Satu atau lebih elemen DOM untuk modal tidak ditemukan.");
                        return;
                    }

                    const beratStr = beratInput.value.trim();

                    // Validasi input sebelum menampilkan modal
                    if (beratStr === "" || isNaN(parseFloat(beratStr)) || parseFloat(beratStr) <= 0) {
                        alert("Berat laundry tidak valid. Harap masukkan angka positif.");
                        beratInput.focus();
                        return;
                    }

                    const berat = parseFloat(beratStr);
                    const totalHarga = berat * hargaPerKg;

                    modalBeratBarang.textContent = berat.toFixed(2); // Tampilkan 2 angka desimal
                    modalTotalHarga.textContent = totalHarga.toLocaleString('id-ID'); // Format angka Indonesia

                    konfirmasiModalInstance.show();
                });
            }

            const btnLanjutkanPembayaran = document.getElementById('btnLanjutkanPembayaran');
            if (btnLanjutkanPembayaran) {
                   btnLanjutkanPembayaran.addEventListener('click', function () {
                    if (realSubmitButton && konfirmasiModalInstance) {
                        // Klik tombol submit tersembunyi untuk mengirim form
                        realSubmitButton.click();
                        // Tidak perlu menyembunyikan modal di sini karena submit akan me-reload halaman
                        // konfirmasiModalInstance.hide(); 
                    } else {
                        console.error("Tombol submit atau instance modal tidak ditemukan.");
                    }
                });
            }
        });
    </script>
    <br><br><br><br><br><br><br><br>
        <?php include 'footer.php' ?>

</body>
</html>
