<?php
session_start();
// Pastikan file koneksi.php Anda ada di lokasi yang sama atau sesuaikan path-nya
include 'koneksi.php';

$success_message = "";
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Melindungi dari SQL injection
    $nama = mysqli_real_escape_string($koneksi, $nama);
    $username = mysqli_real_escape_string($koneksi, $username);
    // Password tidak perlu di-escape sebelum di-hash
    // $password = mysqli_real_escape_string($koneksi, $password);
    // $confirm_password = mysqli_real_escape_string($koneksi, $confirm_password);

    if ($password !== $confirm_password) {
        $error_message = "Konfirmasi password tidak cocok.";
    } else {
        // Cek apakah username sudah ada
        $check_username_sql = "SELECT id_user FROM user WHERE username = '$username'";
        $result_check = mysqli_query($koneksi, $check_username_sql);

        if (mysqli_num_rows($result_check) > 0) {
            $error_message = "Username sudah terdaftar. Silakan gunakan username lain.";
        } else {
            // Hash password sebelum disimpan ke database
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Perhatikan bahwa id_pesanan tidak diisi saat registrasi awal
            // Karena ini adalah foreign key ke tabel pesanan, mungkin akan diisi nanti
            // Atau jika id_pesanan bisa null, pastikan kolom tersebut diizinkan null di database
            $sql = "INSERT INTO user (nama, username, password) VALUES ('$nama', '$username', '$hashed_password')";

            if (mysqli_query($koneksi, $sql)) {
                $success_message = "Pendaftaran berhasil! Anda bisa login sekarang.";
            } else {
                $error_message = "Error: " . $sql . "<br>" . mysqli_error($koneksi);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #6a1b9a; /* Ungu gelap */
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            color: #fff; /* Warna teks putih */
        }
        .register-container {
            background-color: rgba(255, 255, 255, 0.2); /* Sedikit transparan */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 450px;
        }
        .register-container h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #fff;
        }
        .form-label {
            color: #fff;
        }
        .form-control {
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: #fff;
        }
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.2);
            border-color: #dda0dd; /* Ungu muda */
            box-shadow: 0 0 0 0.25rem rgba(221, 160, 221, 0.25);
        }
        .btn-primary {
            background-color: #8e24aa; /* Ungu sedang */
            border-color: #8e24aa;
            width: 100%;
        }
        .btn-primary:hover {
            background-color: #ab47bc; /* Ungu lebih muda */
            border-color: #ab47bc;
        }
        .text-center a {
            color: #dda0dd; /* Ungu muda */
            text-decoration: none;
        }
        .text-center a:hover {
            text-decoration: underline;
        }
        .alert {
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Registrasi</h2>
        <?php if ($success_message): ?>
            <div class="alert alert-success" role="alert">
                <?php echo $success_message; ?> <a href="login.php">Login sekarang!</a>
            </div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        <form action="register.php" method="POST">
            <div class="mb-3">
                <label for="nama" class="form-label">Nama Lengkap</label>
                <input type="text" class="form-control" id="nama" name="nama" required>
            </div>
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <div class="mb-3">
                <label for="confirm_password" class="form-label">Konfirmasi Password</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
            </div>
            <button type="submit" class="btn btn-primary">Daftar</button>
        </form>
        <p class="text-center mt-3">Sudah punya akun? <a href="login.php">Login di sini</a></p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>