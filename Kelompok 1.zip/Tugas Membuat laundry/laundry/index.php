<?php
// Sertakan file navbar.php untuk tampilan navigasi
include 'navbar.php';

// Mulai session (jika diperlukan untuk fitur lain di masa depan, saat ini tidak wajib untuk halaman index)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Sertakan file koneksi database
// Pastikan path ini benar sesuai lokasi file koneksi.php Anda
include 'koneksi.php';

// Variabel untuk menyimpan jumlah total pesanan
$jumlah_pesanan = 0;
$pesan_error = "";

// Query untuk menghitung jumlah total pesanan dari tabel 'pesanan'
$sql_count_pesanan = "SELECT COUNT(id_pesanan) AS total_pesanan FROM pesanan";
$result_count = mysqli_query($koneksi, $sql_count_pesanan);

if ($result_count) {
    $row_count = mysqli_fetch_assoc($result_count);
    $jumlah_pesanan = $row_count['total_pesanan'];
} else {
    $pesan_error = "Gagal mengambil jumlah pesanan: " . mysqli_error($koneksi);
}

// Tutup koneksi database
mysqli_close($koneksi);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selamat Datang di Laundry Harapan</title>
    <!-- Menggunakan Bootstrap dari folder lokal -->
    <!-- Pastikan path ini benar sesuai lokasi file bootstrap.min.css Anda -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0e6f7; /* Ungu muda sebagai background utama halaman */
            color: #333;
        }
        .hero-section {
            position: relative;
            text-align: center;
            color: white;
            margin-bottom: 30px;
        }
        .hero-section img {
            width: 100%;
            height: 300px; /* Tinggi banner tetap */
            object-fit: cover; /* Memastikan gambar menutupi area */
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(106, 27, 154, 0.5); /* Overlay ungu transparan */
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            padding: 20px;
        }
        .hero-overlay h1 {
            font-size: 3rem;
            font-weight: bold;
            color: #fff;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .hero-overlay p {
            font-size: 1.2rem;
            margin-top: 10px;
        }
        .content-section {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(106, 27, 154, 0.2);
            margin-bottom: 30px;
        }
        .content-section h3 {
            color: #6a1b9a;
            margin-bottom: 20px;
        }
        .stats-card {
            background-color: #8e24aa; /* Ungu sedang */
            color: #fff;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .stats-card h4 {
            font-size: 1.5rem;
            margin-bottom: 10px;
        }
        .stats-card p {
            font-size: 2.5rem;
            font-weight: bold;
            margin: 0;
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <?php 
    // Sertakan navbar Anda
    // Pastikan path ini benar sesuai lokasi file navbar.php Anda
    ?>

    <div class="container mt-4">
        <div class="hero-section">
            <img src="images/banner.png" alt="Banner Laundry Harapan" onerror="this.onerror=null;this.src='https://placehold.co/1200x300/8e24aa/ffffff?text=Banner+Laundry+Harapan';">
            <div class="hero-overlay">
                <h1>Selamat Datang di Laundry Harapan</h1>
                <p>Solusi laundry bersih, wangi, dan terpercaya untuk Anda.</p>
            </div>
        </div>

        <div class="content-section">
            <h3>Tentang Kami</h3>
            <p>
                Laundry Harapan hadir untuk memenuhi kebutuhan laundry Anda dengan pelayanan terbaik. Kami menggunakan deterjen berkualitas tinggi dan proses pencucian yang higienis untuk memastikan pakaian Anda bersih sempurna, wangi tahan lama, dan terawat. Dengan tim profesional dan peralatan modern, kami berkomitmen memberikan hasil yang memuaskan setiap saat. Percayakan kebutuhan laundry Anda kepada kami dan nikmati kenyamanan hidup tanpa repot mencuci!
            </p>
            <p>
                Kami melayani berbagai jenis cucian, mulai dari pakaian sehari-hari, selimut, bed cover, hingga pakaian khusus. Harga yang terjangkau dan proses yang cepat menjadikan Laundry Harapan pilihan tepat bagi Anda yang sibuk.
            </p>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4">
                <div class="stats-card">
                    <h4>Total Pesanan Diterima</h4>
                    <?php if (!empty($pesan_error)): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo htmlspecialchars($pesan_error); ?>
                        </div>
                    <?php else: ?>
                        <p><?php echo htmlspecialchars($jumlah_pesanan); ?></p>
                    <?php endif; ?>
            
                </div>
            </div>
        </div>
    </div>
<br>
<br>
    <?php include 'footer.php' ?>

    <!-- Menggunakan Bootstrap JS dari folder lokal -->
    <!-- Pastikan path ini benar sesuai lokasi file bootstrap.bundle.min.js Anda -->
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
