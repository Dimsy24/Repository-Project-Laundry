<?php
$title = 'Kelola Layanan';
require '../config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
  header("Location: ../login.php");
  exit;
}

// Tangkap data untuk diedit
$edit_data = null;
if (isset($_GET['edit'])) {
  $edit_id = intval($_GET['edit']);
  $edit_data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM layanan WHERE id=$edit_id"));
}

// Proses update
if (isset($_POST['update'])) {
  $id = intval($_POST['id']);
  $nama = $_POST['nama'];
  $desc = $_POST['deskripsi'];
  $harga = $_POST['harga'];
  $durasi = $_POST['durasi'];
  mysqli_query($conn, "UPDATE layanan SET nama_layanan='$nama', deskripsi='$desc', harga_per_kg=$harga, durasi='$durasi' WHERE id=$id");
  header("Location: layanan.php");
  exit;
}

// Tambah layanan baru
if (isset($_POST['add'])) {
  $nama = $_POST['nama'];
  $desc = $_POST['deskripsi'];
  $harga = $_POST['harga'];
  $durasi = $_POST['durasi'];
  mysqli_query($conn, "INSERT INTO layanan (nama_layanan, deskripsi, harga_per_kg, durasi) VALUES ('$nama','$desc',$harga,'$durasi')");
}

// Hapus layanan
if (isset($_GET['del'])) {
  $id = intval($_GET['del']);
  mysqli_query($conn, "DELETE FROM layanan WHERE id=$id");
  header("Location: layanan.php");
  exit;
}

$layanan = mysqli_query($conn, "SELECT * FROM layanan");
require '../header.php';
?>

<h2 class="mb-4">Kelola Layanan</h2>

<form method="post" class="row g-2 mb-4">
  <?php if ($edit_data): ?>
    <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>">
  <?php endif; ?>
  <div class="col-md-3">
    <input type="text" name="nama" class="form-control" placeholder="Nama" required value="<?php echo $edit_data['nama_layanan'] ?? ''; ?>">
  </div>
  <div class="col-md-3">
    <input type="text" name="deskripsi" class="form-control" placeholder="Deskripsi" value="<?php echo $edit_data['deskripsi'] ?? ''; ?>">
  </div>
  <div class="col-md-2">
    <input type="number" step="0.01" name="harga" class="form-control" placeholder="Harga/kg" required value="<?php echo $edit_data['harga_per_kg'] ?? ''; ?>">
  </div>
  <div class="col-md-2">
    <input type="text" name="durasi" class="form-control" placeholder="Durasi" value="<?php echo $edit_data['durasi'] ?? ''; ?>">
  </div>
  <div class="col-md-2">
    <?php if ($edit_data): ?>
      <button class="btn btn-warning w-100" name="update">Update</button>
    <?php else: ?>
      <button class="btn btn-success w-100" name="add">Tambah</button>
    <?php endif; ?>
  </div>
</form>

<table class="table table-bordered">
  <thead>
    <tr>
      <th>ID</th>
      <th>Nama</th>
      <th>Deskripsi</th>
      <th>Harga</th>
      <th>Durasi</th>
      <th>Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php while ($l = mysqli_fetch_assoc($layanan)): ?>
      <tr>
        <td><?php echo $l['id']; ?></td>
        <td><?php echo $l['nama_layanan']; ?></td>
        <td><?php echo $l['deskripsi']; ?></td>
        <td>Rp <?php echo number_format($l['harga_per_kg'], 0, ',', '.'); ?></td>
        <td><?php echo $l['durasi']; ?></td>
        <td>
          <a href="?edit=<?php echo $l['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
          <a href="?del=<?php echo $l['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus layanan?')">Hapus</a>
        </td>
      </tr>
    <?php endwhile; ?>
  </tbody>
</table>

<?php require '../footer.php'; ?>
