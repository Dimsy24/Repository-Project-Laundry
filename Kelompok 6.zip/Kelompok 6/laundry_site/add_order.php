<?php
$title='Pesan Laundry';
require 'config.php';
if(!isset($_SESSION['user'])){ header("Location: login.php"); exit; }

$layanan=mysqli_query($conn,"SELECT * FROM layanan");
if(isset($_POST['submit'])){
  $id_user=$_SESSION['user']['id'];
  $tgl=date('Y-m-d');
  $status='diproses';
  $berat=$_POST['berat'];
  $id_layanan=$_POST['id_layanan'];
  $l=mysqli_fetch_assoc(mysqli_query($conn,"SELECT harga_per_kg FROM layanan WHERE id=$id_layanan"));
  $total=$berat*$l['harga_per_kg'];
  mysqli_query($conn,"INSERT INTO pesanan (id_user,tanggal_masuk,status,total_berat,total_harga) VALUES ($id_user,'$tgl','$status',$berat,$total)");
  $id_pesanan=mysqli_insert_id($conn);
  mysqli_query($conn,"INSERT INTO pesanan_detail (id_pesanan,id_layanan,berat,subtotal) VALUES ($id_pesanan,$id_layanan,$berat,$total)");
  header("Location: dashboard.php");
  exit;
}
require 'header.php';
?>
<h2 class="mb-4">Buat Pesanan</h2>
<form method="post">
  <div class="mb-3">
    <label class="form-label">Layanan</label>
    <select name="id_layanan" class="form-select" required>
      <?php while($l=mysqli_fetch_assoc($layanan)): ?>
        <option value="<?php echo $l['id']; ?>"><?php echo $l['nama_layanan']; ?> - Rp <?php echo number_format($l['harga_per_kg'],0,',','.'); ?>/kg</option>
      <?php endwhile; ?>
    </select>
  </div>
  <div class="mb-3">
    <label class="form-label">Berat (kg)</label>
    <input type="number" step="0.1" name="berat" class="form-control" required>
  </div>
  <button class="btn btn-primary" name="submit">Kirim Pesanan</button>
</form>
<?php require 'footer.php'; ?>
