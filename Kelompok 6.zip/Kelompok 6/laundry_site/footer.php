<footer style="
  background-color: rgb(255, 255, 255); 
  color: #0F256D; 
  box-shadow: 0 -6px 12px rgba(0, 0, 0, 0.08); 
  text-align: center; 
  padding-top: 1.5rem; 
  padding-bottom: 1.5rem; 
  margin-top: 3rem; 
  border-top: 1px solid rgba(0, 0, 0, 0.125);
">
  <div style="max-width: 1140px; margin: 0 auto;">
    <p style="margin-bottom: 0.25rem; font-weight: 600;">
      &copy; 2025 <span style="color: #0F92D0;">DLaundry</span>. All rights reserved.
    </p>
    <p style="font-size: 0.875rem; color: #6c757d; margin-bottom: 0.5rem;">
      Bersih, wangi, dan terpercaya.
    </p>

    <div style="margin-top: 0.5rem; font-size: 1.5rem;">
      <a href="#" style="color: #0F256D; margin-right: 1rem; text-decoration: none;" onmouseover="this.style.color='#00B0F0'" onmouseout="this.style.color='#0F256D'">
        <i class="bi bi-facebook"></i>
      </a>
      <a href="#" style="color: #0F256D; margin-right: 1rem; text-decoration: none;" onmouseover="this.style.color='#00B0F0'" onmouseout="this.style.color='#0F256D'">
        <i class="bi bi-instagram"></i>
      </a>
      <a href="#" style="color: #0F256D; text-decoration: none;" onmouseover="this.style.color='#00B0F0'" onmouseout="this.style.color='#0F256D'">
        <i class="bi bi-whatsapp"></i>
      </a>
    </div>
  </div>

  <!-- AOS JS -->
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({
    duration: 1000, // durasi animasi dalam ms
    once: true // animasi hanya sekali saat scroll
  });
</script>

</footer>
