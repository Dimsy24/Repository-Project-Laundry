<?php
$title='Daftar';
require 'config.php';
if(isset($_POST['register'])){
  $username=$_POST['username'];
  $password=password_hash($_POST['password'],PASSWORD_BCRYPT);
  $nama=$_POST['nama'];
  $telp=$_POST['telp'];
  $alamat=$_POST['alamat'];
  $ok=mysqli_query($conn,"INSERT INTO users (username,password,nama_lengkap,telepon,alamat) VALUES ('$username','$password','$nama','$telp','$alamat')");
  if($ok){
      header("Location: login.php");
      exit;
  } else {
      $error='Gagal mendaftar: '.mysqli_error($conn);
  }
}
require 'header.php';
?>
<h2 class="mb-4">Daftar</h2>
<?php if(isset($error)): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
<form method="post">
  <div class="mb-3">
    <label class="form-label">Username</label>
    <input type="text" name="username" class="form-control" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Password</label>
    <input type="password" name="password" class="form-control" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Nama Lengkap</label>
    <input type="text" name="nama" class="form-control">
  </div>
  <div class="mb-3">
    <label class="form-label">Telepon</label>
    <input type="text" name="telp" class="form-control">
  </div>
  <div class="mb-3">
    <label class="form-label">Alamat</label>
    <textarea name="alamat" class="form-control"></textarea>
  </div>
  <button class="btn btn-primary" name="register">Daftar</button>
</form>
<?php require 'footer.php'; ?>
