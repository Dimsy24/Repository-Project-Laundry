<?php
$title='Beranda';
require 'config.php';
require 'header.php';
$layanan=mysqli_query($conn,"SELECT * FROM layanan");
?>

<div class="container text-center py-5 hero-section" data-aos="fade-up">
  <div class="container text-center py-5 hero-content">
    <h1 class="display-3 fw-bold">Di Cuci, Di Setrika, DLaundry aja.</h1>
    <p class="fs-4">Solusi mudah untuk pakaian bersih setiap hari.</p>
    <?php if(!isset($_SESSION['user'])): ?>
      <a class="btn btn-light btn-lg mt-3" href="register.php">Daftar Sekarang</a>
    <?php else: ?>
      <a class="btn btn-light btn-lg btn-pesan mt-3" href="add_order.php">Pesan Laundry</a>
    <?php endif; ?>
  </div>
</div>

<!-- ✅ Bagian Tentang Kami -->
<section class="bg-white my-5 py-5">
  <div class="container">
    <h2 class="text-center fw-bold mb-4" style="color: #0F256D;">Tentang Kami</h2>
    <div class="row align-items-center">
      <div class="col-md-6 mb-4 mb-md-0">
        <img src="image/laundrypic.png" alt="Tentang DLaundry" class="img-fluid rounded shadow" data-aos="fade-right">
      </div>
      <div class="col-md-6" data-aos="fade-left">
        <p class="fs-5">
          <strong>DLaundry</strong> adalah solusi modern untuk kebutuhan laundry Anda. Dengan layanan cepat, bersih, dan wangi, kami siap membantu Anda menghemat waktu dan tenaga. 
          Kami melayani dengan profesionalisme dan teknologi terkini untuk menjaga kualitas cucian Anda.
        </p>
        <p class="text-muted">Kami percaya bahwa pakaian bersih mencerminkan hidup yang sehat dan nyaman.</p>
      </div>
    </div>
  </div>
</section>

<!-- ✅ Bagian Layanan Kami -->
<h2 class="text-center fw-bold mb-4" style="color: #0F256D;">Layanan Kami</h2>
<div class="row">
<?php
$index = 0;
$delay_step = 100; // misal 100ms setiap layanan
while($row = mysqli_fetch_assoc($layanan)):
  $delay = $index * $delay_step;
?>

  <div class="col-md-4 mb-3" data-aos="fade-up" data-aos-delay="<?php echo $delay; ?>">
    <a href="add_order.php" class="card h-100 shadow-sm">
      <img 
      src="image/wash1.gif?<?php echo urlencode($row['nama_layanan']); ?>" class="card-img-top" 
      alt="<?php echo $row['nama_layanan']; ?>" 
      style="height: 300px; object-fit: cover; width: 100%; ">
    <div class="card-body p-2">
      <h6 class="card-title mb-1"><?php echo $row['nama_layanan']; ?></h6>
      <p class="card-text mb-2" style="font-size: 0.9rem;"><?php echo $row['deskripsi']; ?></p>
      <p class="fw-bold mb-0" style="font-size: 0.9rem;">Rp <?php echo number_format($row['harga_per_kg'], 0, ',', '.'); ?> / kg</p>
    </div>
    </a>
</div>


<?php
  $index++;
endwhile;
?>
</div>

<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({
    duration: 1250,
    once: true
  });
</script>

<?php require 'footer.php'; ?>
