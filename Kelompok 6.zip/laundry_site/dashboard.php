<?php
$title='Dashboard';
require 'config.php';
if(!isset($_SESSION['user'])){ header("Location: login.php"); exit; }
$user_id=$_SESSION['user']['id'];
$orders=mysqli_query($conn,"SELECT * FROM pesanan WHERE id_user=$user_id ORDER BY id DESC");
require 'header.php';
?>
<h2 class="mb-4">Pesanan Saya</h2>
<a href="add_order.php" class="btn btn-success mb-3">Buat Pesanan Baru</a>
<table class="table table-bordered">
  <thead><tr><th>ID</th><th>Tanggal Masuk</th><th>Status</th><th>Total (Rp)</th></tr></thead>
  <tbody>
  <?php while($o=mysqli_fetch_assoc($orders)): ?>
    <tr>
      <td><?php echo $o['id']; ?></td>
      <td><?php echo $o['tanggal_masuk']; ?></td>
      <td><?php echo $o['status']; ?></td>
      <td><?php echo number_format($o['total_harga'],0,',','.'); ?></td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>
<?php require 'footer.php'; ?>
