<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $title ?? 'Laundry'; ?></title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- AOS CSS -->
<link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet">

  <!-- Custom Styles -->
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f8f9fa;
    }

    /* Navbar */
    .navbar {
      background-color:rgb(255, 255, 255);
      box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    }

    .navbar-brand span {
      font-size: 1.75rem;
    }

    .navbar-toggler {
      border: none;
    }

    .navbar-toggler:focus {
      box-shadow: none;
    }

    .nav-link.nav-hover {
      transition: 0.3s;
    }

    .nav-link.nav-hover:hover {
      color: #00B0F0 !important;
      text-decoration: underline;
    }

    /* Button hover */
    .btn-pesan {
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .btn-pesan:hover {
      transform: translateY(-4px);
      box-shadow: 0 6px 12px rgba(0,0,0,0.15);
    }

    /* Logo */
    .navbar-logo {
      width: 60px;
      height: 60px;
      object-fit: cover;
      border: 2px solid #ffffff;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
    }

    /* Optional: add gradient background to sections */
    .hero-section {
      background: linear-gradient(to right,rgb(255, 255, 255),rgb(228, 228, 228));
      color: white;
      padding: 4rem 2rem;
      border-radius: 1rem;
      margin-bottom: 2rem;
    }
  </style>
  <style>
.hero-section {
  position: relative;
  background: url('image/bglaundry.jpg') center/cover no-repeat;
  border-radius: 1rem;
  margin-bottom: rem;
  overflow: hidden;
}

.hero-section::before {
  content: "";
  position: absolute;
  inset: 0;
  background-color: rgba(0, 0, 0, 0.5); /* 50% hitam transparan */
}

.hero-content {
  position: relative;
  z-index: 1;
  color: white;
}
.text-primary-brand {
  color: #0F256D !important;
}

</style>
</head>

<body>
  <!-- NAVBAR -->
  <nav class="navbar navbar-expand-lg bg-light">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center gap-2 text-primary-brand" href="/laundry_site/index.php">
      <img src="image/dlaundry_logo.jpeg" alt="Logo" class="rounded-circle navbar-logo">
      <span class="fw-bold">DLaundry</span>
    </a>
    <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#nav" aria-controls="nav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav ms-auto">
        <?php if(isset($_SESSION['user'])): ?>
          <li class="nav-item"><a class="nav-link text-primary-brand nav-hover" href="/laundry_site/dashboard.php">Dashboard</a></li>
          <?php if($_SESSION['user']['role']=='admin'): ?>
            <li class="nav-item"><a class="nav-link text-primary-brand nav-hover" href="/laundry_site/admin/layanan.php">Kelola Layanan</a></li>
            <li class="nav-item"><a class="nav-link text-primary-brand nav-hover" href="/laundry_site/admin/users.php">Kelola Pengguna</a></li>
            <li class="nav-item"><a class="nav-link text-primary-brand nav-hover" href="/laundry_site/admin/orders.php">Kelola Pesanan</a></li>
          <?php endif; ?>
          <li class="nav-item"><a class="nav-link text-primary-brand nav-hover" href="/laundry_site/logout.php">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link text-primary-brand nav-hover" href="/laundry_site/login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>


  <!-- CONTENT WRAPPER -->
  <div class="container">
