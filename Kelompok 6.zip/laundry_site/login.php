<?php
$title='Login';
require 'config.php';
if(isset($_POST['login'])){
  $username=$_POST['username'];
  $password=$_POST['password'];
  $q=mysqli_query($conn,"SELECT * FROM users WHERE username='$username'");
  if($row=mysqli_fetch_assoc($q)){
    if(password_verify($password,$row['password'])){
       $_SESSION['user']=$row;
       header("Location: index.php");
       exit;
    }
  }
  $error="Username atau password salah";
}
require 'header.php';
?>
<h2 class="mb-4">Login</h2>
<?php if(isset($error)): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
<form method="post">
  <div class="mb-3">
    <label class="form-label">Username</label>
    <input type="text" name="username" class="form-control" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Password</label>
    <input type="password" name="password" class="form-control" required>
  </div>
  <button class="btn btn-primary" name="login">Login</button>
</form>
<p class="mt-3">Belum punya akun? <a href="register.php">Daftar di sini</a></p>
<?php require 'footer.php'; ?>
