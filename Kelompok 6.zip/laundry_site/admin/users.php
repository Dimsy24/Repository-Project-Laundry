<?php
$title = 'Kelola Pengguna';
require '../config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// Ambil data user untuk edit jika diminta
$edit_user = null;
if (isset($_GET['edit'])) {
    $edit_id = intval($_GET['edit']);
    $edit_user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id=$edit_id"));
}

// Tambah atau update user
if (isset($_POST['simpan'])) {
    $id = intval($_POST['id'] ?? 0);
    $username = $_POST['username'];
    $nama = $_POST['nama'];
    $telp = $_POST['telp'];
    $alamat = $_POST['alamat'];
    $role = $_POST['role'];
    $password = $_POST['password'];

    if ($id > 0) {
        // update
        $sql = "UPDATE users SET username='$username', nama_lengkap='$nama', telepon='$telp', alamat='$alamat', role='$role'";
        if ($password != '') {
            $pass_hash = password_hash($password, PASSWORD_BCRYPT);
            $sql .= ", password='$pass_hash'";
        }
        $sql .= " WHERE id=$id";
        mysqli_query($conn, $sql);
    } else {
        // insert
        $pass_hash = password_hash($password, PASSWORD_BCRYPT);
        mysqli_query($conn, "INSERT INTO users (username, password, nama_lengkap, telepon, alamat, role) VALUES ('$username','$pass_hash','$nama','$telp','$alamat','$role')");
    }
    header("Location: users.php");
    exit;
}

// Hapus user
if (isset($_GET['del'])) {
    $id = intval($_GET['del']);
    mysqli_query($conn, "DELETE FROM users WHERE id=$id");
    header("Location: users.php");
    exit;
}

$users = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
require '../header.php';
?>

<h2 class="mb-4">Kelola Pengguna</h2>

<form method="post" class="row g-2 mb-4">
  <?php if ($edit_user): ?>
  <input type="hidden" name="id" value="<?php echo $edit_user['id']; ?>">
  <?php endif; ?>
  <div class="col-md-2">
    <input type="text" name="username" class="form-control" placeholder="Username" required value="<?php echo $edit_user['username'] ?? ''; ?>">
  </div>
  <div class="col-md-2">
    <input type="text" name="nama" class="form-control" placeholder="Nama Lengkap" required value="<?php echo $edit_user['nama_lengkap'] ?? ''; ?>">
  </div>
  <div class="col-md-2">
    <input type="text" name="telp" class="form-control" placeholder="Telepon" value="<?php echo $edit_user['telepon'] ?? ''; ?>">
  </div>
  <div class="col-md-2">
    <input type="text" name="alamat" class="form-control" placeholder="Alamat" value="<?php echo $edit_user['alamat'] ?? ''; ?>">
  </div>
  <div class="col-md-2">
    <select name="role" class="form-select">
      <option value="pelanggan" <?php if (($edit_user['role'] ?? '') == 'pelanggan') echo 'selected'; ?>>Pelanggan</option>
      <option value="admin" <?php if (($edit_user['role'] ?? '') == 'admin') echo 'selected'; ?>>Admin</option>
    </select>
  </div>
  <div class="col-md-2">
    <input type="password" name="password" class="form-control" placeholder="<?php echo $edit_user ? 'Ganti Password' : 'Password'; ?>">
  </div>
  <div class="col-12">
    <button class="btn btn-<?php echo $edit_user ? 'warning' : 'primary'; ?>" name="simpan">
      <?php echo $edit_user ? 'Update' : 'Tambah'; ?> Pengguna
    </button>
  </div>
</form>

<table class="table table-bordered">
  <thead><tr><th>ID</th><th>Username</th><th>Nama</th><th>Telepon</th><th>Alamat</th><th>Role</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php while($u = mysqli_fetch_assoc($users)): ?>
    <tr>
      <td><?php echo $u['id']; ?></td>
      <td><?php echo $u['username']; ?></td>
      <td><?php echo $u['nama_lengkap']; ?></td>
      <td><?php echo $u['telepon']; ?></td>
      <td><?php echo $u['alamat']; ?></td>
      <td><?php echo $u['role']; ?></td>
      <td>
        <a href="?edit=<?php echo $u['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
        <a href="?del=<?php echo $u['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus user ini?')">Hapus</a>
      </td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>

<?php require '../footer.php'; ?>
