<?php
$title = 'Kelola Pesanan';
require '../config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
  header("Location: ../login.php");
  exit;
}

// Ambil pesanan untuk diedit
$edit_data = null;
if (isset($_GET['edit'])) {
  $id = intval($_GET['edit']);
  $edit_data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM pesanan WHERE id=$id"));
}

// Proses update pesanan
if (isset($_POST['update'])) {
  $id = intval($_POST['id']);
  $status = $_POST['status'];
  $catatan = $_POST['catatan'];
  mysqli_query($conn, "UPDATE pesanan SET status='$status', catatan_admin='$catatan' WHERE id=$id");
  header("Location: orders.php");
  exit;
}

// Hapus pesanan
if (isset($_GET['del'])) {
  $id = intval($_GET['del']);
  mysqli_query($conn, "DELETE FROM pesanan WHERE id=$id");
  header("Location: orders.php");
  exit;
}

$orders = mysqli_query($conn, "SELECT p.*, u.nama_lengkap, l.nama_layanan 
FROM pesanan p
JOIN users u ON p.user_id = u.id
JOIN layanan l ON p.layanan_id = l.id
ORDER BY p.id DESC");


require '../header.php';
?>

<h2 class="mb-4">Kelola Pesanan</h2>

<?php if ($edit_data): ?>
<form method="post" class="row g-2 mb-4">
  <input type="hidden" name="id" value="<?php echo $edit_data['id']; ?>">
  <div class="col-md-3">
    <select name="status" class="form-select" required>
      <?php
        $status_list = ['Menunggu', 'Diproses', 'Selesai', 'Diambil'];
        foreach ($status_list as $s) {
          $sel = $s == $edit_data['status'] ? 'selected' : '';
          echo "<option $sel>$s</option>";
        }
      ?>
    </select>
  </div>
  <div class="col-md-6">
    <input type="text" name="catatan" class="form-control" placeholder="Catatan Admin" value="<?php echo $edit_data['catatan_admin']; ?>">
  </div>
  <div class="col-md-3">
    <button class="btn btn-warning w-100" name="update">Update Pesanan</button>
  </div>
</form>
<?php endif; ?>

<table class="table table-bordered table-striped">
  <thead>
    <tr>
      <th>ID</th>
      <th>Pelanggan</th>
      <th>Layanan</th>
      <th>Berat (kg)</th>
      <th>Total</th>
      <th>Status</th>
      <th>Catatan</th>
      <th>Tanggal</th>
      <th>Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php while($o = mysqli_fetch_assoc($orders)): ?>
    <tr>
      <td><?php echo $o['id']; ?></td>
      <td><?php echo $o['nama_lengkap']; ?></td>
      <td><?php echo $o['nama_layanan']; ?></td>
      <td><?php echo $o['berat']; ?></td>
      <td>Rp <?php echo number_format($o['total_harga'], 0, ',', '.'); ?></td>
      <td><?php echo $o['status']; ?></td>
      <td><?php echo $o['catatan_admin']; ?></td>
      <td><?php echo $o['tanggal_pesan']; ?></td>
      <td>
        <a href="?edit=<?php echo $o['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
        <a href="?del=<?php echo $o['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus pesanan ini?')">Hapus</a>
      </td>
    </tr>
    <?php endwhile; ?>
  </tbody>
</table>

<?php require '../footer.php'; ?>
