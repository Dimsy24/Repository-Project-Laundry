<?php
require 'config.php';

$username = 'admin';
$password = password_hash('admin123', PASSWORD_BCRYPT);
$nama = 'Administrator';

$query = mysqli_query($conn, "INSERT INTO users (username, password, nama_lengkap, role) 
VALUES ('$username', '$password', '$nama', 'admin')");

if ($query) {
    echo "Admin berhasil ditambahkan!";
} else {
    echo "Gagal: " . mysqli_error($conn);
}
?>
